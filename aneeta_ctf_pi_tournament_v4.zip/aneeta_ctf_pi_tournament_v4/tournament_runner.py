from __future__ import annotations

import argparse
import os
from pathlib import Path

from aneeta.autopilot.engine import AutopilotEngine
from aneeta.ollama.client import OllamaClient
from aneeta.plugins.registry import SolverRegistry
from aneeta.tournament.config import load_adapter
from aneeta.tournament.runner import (
    BrowserTournamentRunner,
    RunnerPaths,
)

BASE_DIR = Path(__file__).resolve().parent


def main() -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Aneeta CTF tournament runner. Live submissions are disabled "
            "unless the adapter and CLI both confirm permission."
        )
    )
    parser.add_argument(
        "--config",
        required=True,
        help="Path to adapter JSON.",
    )

    mode = parser.add_mutually_exclusive_group()
    mode.add_argument(
        "--dry-run",
        action="store_true",
        help="Solve and queue a candidate without submitting.",
    )
    mode.add_argument(
        "--live",
        action="store_true",
        help="Submit eligible flags and move to the next challenge.",
    )
    mode.add_argument(
        "--login-only",
        action="store_true",
        help="Open the persistent browser profile for manual login.",
    )

    parser.add_argument(
        "--confirm-permission",
        action="store_true",
        help="Confirm the platform rules permit this automation.",
    )
    parser.add_argument(
        "--headless",
        action="store_true",
        help="Run Chromium without a visible window.",
    )
    args = parser.parse_args()

    config_path = Path(args.config)
    if not config_path.is_absolute():
        config_path = BASE_DIR / config_path
    config = load_adapter(config_path)

    client = OllamaClient(
        base_url=os.getenv(
            "OLLAMA_URL",
            "http://127.0.0.1:11434",
        ),
        model=os.getenv("OLLAMA_MODEL", "llama3.2:1b"),
        timeout=int(os.getenv("OLLAMA_TIMEOUT", "120")),
        keep_alive=os.getenv("OLLAMA_KEEP_ALIVE", "10m"),
    )
    autopilot = AutopilotEngine(
        client=client,
        registry=SolverRegistry(),
        max_rounds=int(os.getenv("AUTOPILOT_MAX_ROUNDS", "3")),
    )

    runner = BrowserTournamentRunner(
        config=config,
        autopilot=autopilot,
        paths=RunnerPaths.from_base(BASE_DIR, config.name),
    )

    if args.login_only:
        runner.login_only(headless=args.headless)
        return 0

    live = bool(args.live)
    summary = runner.run(
        live=live,
        confirm_permission=bool(args.confirm_permission),
        headless=bool(args.headless),
    )
    print("\nTournament runner summary")
    for key, value in summary.items():
        print(f"{key}: {value}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
