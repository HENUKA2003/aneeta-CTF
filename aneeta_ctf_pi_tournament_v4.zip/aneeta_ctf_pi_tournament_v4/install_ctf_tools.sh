#!/usr/bin/env bash
set -u
cd "$(dirname "$0")"
sudo apt update

packages=(
  tshark
  libimage-exiftool-perl
  binwalk
  steghide
  zbar-tools
  poppler-utils
  p7zip-full
  radare2
)

for package in "${packages[@]}"; do
  echo
  echo "Installing optional package: ${package}"
  if ! sudo DEBIAN_FRONTEND=noninteractive apt install -y "${package}"; then
    echo "Warning: ${package} unavailable or failed."
  fi
done

echo
echo "Optional CTF tools installation finished."
