from __future__ import annotations

from flask import Flask, redirect, render_template_string, request, session, url_for

app = Flask(__name__)
app.secret_key = "aneeta-local-demo-only"

CHALLENGES = [
    {
        "title": "Base64 Warmup",
        "text": "Decode: TGVnaW9ue2RlbW9fYmFzZTY0fQ==",
        "flag": "Legion{demo_base64}",
        "points": 50,
    },
    {
        "title": "Hex Warmup",
        "text": (
            "Decode: "
            "4c6567696f6e7b64656d6f5f6865787d"
        ),
        "flag": "Legion{demo_hex}",
        "points": 50,
    },
    {
        "title": "ROT13 Warmup",
        "text": "Decode: Yrtvba{qrzb_ebg13}",
        "flag": "Legion{demo_rot13}",
        "points": 50,
    },
    {
        "title": "Decimal ASCII",
        "text": (
            "Decode decimal ASCII: "
            "76 101 103 105 111 110 123 100 101 109 111 95 "
            "109 105 115 99 125"
        ),
        "flag": "Legion{demo_misc}",
        "points": 50,
    },
]

PAGE = """
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>Aneeta Local Demo CTF</title>
    <style>
        body { font-family: sans-serif; max-width: 760px; margin: 50px auto; }
        .challenge { padding: 24px; border: 1px solid #aaa; border-radius: 12px; }
        input { width: 100%; padding: 10px; box-sizing: border-box; }
        button, a { display: inline-block; margin-top: 12px; padding: 10px 14px; }
        .correct { color: green; font-weight: bold; }
        .incorrect { color: darkred; font-weight: bold; }
    </style>
</head>
<body>
    <div class="challenge">
        <p>Local demo points: {{ points }}</p>
        <h1 id="challenge-title">{{ challenge.title }}</h1>
        <pre id="challenge-text">{{ challenge.text }}</pre>

        <form method="post">
            <input id="flag-input" name="flag" placeholder="Legion{...}">
            <button id="submit-flag" type="submit">Submit flag</button>
        </form>

        {% if status == "correct" %}
            <p id="correct-result" class="correct">Correct flag!</p>
            {% if next_index is not none %}
                <a id="next-challenge"
                   href="{{ url_for('challenge', index=next_index) }}">
                    Next challenge
                </a>
            {% else %}
                <a id="next-challenge"
                   href="{{ url_for('complete') }}">
                    Finish
                </a>
            {% endif %}
        {% elif status == "incorrect" %}
            <p id="incorrect-result" class="incorrect">Incorrect flag.</p>
            <a id="next-challenge"
               href="{{ url_for('challenge', index=index) }}">
                Retry
            </a>
        {% else %}
            <a id="next-challenge"
               href="{{ url_for('challenge', index=index) }}"
               style="display:none">Hidden until solved</a>
        {% endif %}
    </div>
</body>
</html>
"""

COMPLETE = """
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Complete</title></head>
<body>
    <h1 id="challenge-title">Tournament complete</h1>
    <p id="challenge-text">All local demo challenges were solved.</p>
    <p id="correct-result">Correct - complete.</p>
    <input id="flag-input" style="display:none">
    <button id="submit-flag" style="display:none">Submit</button>
    <a id="next-challenge" href="/challenge/0" style="display:none">Restart</a>
</body>
</html>
"""


@app.get("/")
def home():
    return redirect(url_for("challenge", index=0))


@app.route("/challenge/<int:index>", methods=["GET", "POST"])
def challenge(index: int):
    if index < 0 or index >= len(CHALLENGES):
        return redirect(url_for("complete"))

    challenge_item = CHALLENGES[index]
    status = ""
    if request.method == "POST":
        submitted = request.form.get("flag", "")
        if submitted == challenge_item["flag"]:
            status = "correct"
            solved = set(session.get("solved", []))
            solved.add(index)
            session["solved"] = sorted(solved)
        else:
            status = "incorrect"

    solved_set = set(session.get("solved", []))
    points = sum(
        item["points"]
        for number, item in enumerate(CHALLENGES)
        if number in solved_set
    )
    next_index = index + 1 if index + 1 < len(CHALLENGES) else None
    return render_template_string(
        PAGE,
        challenge=challenge_item,
        index=index,
        next_index=next_index,
        status=status,
        points=points,
    )


@app.get("/complete")
def complete():
    return render_template_string(COMPLETE)


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8088, debug=False)
