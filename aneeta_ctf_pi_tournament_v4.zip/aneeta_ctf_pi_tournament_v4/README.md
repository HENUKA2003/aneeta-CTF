# Aneeta CTF Pi - Tournament V4

This version adds a guarded tournament runner to Categories V3.

## New features

- Generic JSON platform adapters
- Exact-origin allowlist
- Persistent manual-login browser profiles
- Dry-run mode
- Live auto-submit mode with double permission confirmation
- Flag confidence threshold
- Per-challenge and global rejection limits
- Correct/incorrect response detection
- Auto-next only after a correct response
- Emergency stop file and dashboard buttons
- JSONL tournament logs
- Safe local demo CTF for end-to-end testing
- Complete setup and user guides

## Download and install

See:

- `SETUP_GUIDE.md`
- `USER_GUIDE.md`

Basic commands:

```bash
chmod +x *.sh
./setup_pi.sh
./install_ctf_tools.sh
./install_ollama_arm64.sh
./pull_ollama_model.sh
```

Local demo:

```bash
./start_demo.sh
./run_demo_dry.sh
./run_demo_live.sh
```

Real platform:

```bash
cp adapters/template_platform.json adapters/my_platform.json
python tournament_runner.py --config adapters/my_platform.json --login-only
python tournament_runner.py --config adapters/my_platform.json --dry-run
python tournament_runner.py \
  --config adapters/my_platform.json \
  --live \
  --confirm-permission
```

Live mode only works when the adapter also contains:

```json
"automation_permitted": true
```

Use only where platform/competition rules permit automation.
