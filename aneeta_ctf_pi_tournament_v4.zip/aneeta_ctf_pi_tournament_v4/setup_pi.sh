#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

sudo apt update
sudo apt install -y \
  python3 \
  python3-venv \
  python3-pip \
  file \
  unzip \
  nmap

python3 -m venv .venv
source .venv/bin/activate

python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m playwright install --with-deps chromium

mkdir -p runtime/uploads runtime/captures runtime/logs runtime/browser_profile runtime/category_reports
chmod 700 runtime/captures runtime/browser_profile
chmod +x setup_pi.sh

echo
echo "Setup complete."
echo "Dashboard: source .venv/bin/activate && python app.py"
echo "Browser capture: source .venv/bin/activate && python browser_capture.py"

echo "Optional forensics tools: ./install_ctf_tools.sh"

echo "Tournament demo: ./start_demo.sh then ./run_demo_dry.sh"
