#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
USER_NAME="$(id -un)"
SERVICE_TMP="/tmp/aneeta-ctf.service"

sed \
  -e "s|User=pi|User=${USER_NAME}|" \
  -e "s|/home/pi/aneeta_ctf_pi_full|${PROJECT_DIR}|g" \
  "${PROJECT_DIR}/systemd/aneeta-ctf.service" > "${SERVICE_TMP}"

sudo cp "${SERVICE_TMP}" /etc/systemd/system/aneeta-ctf.service
sudo systemctl daemon-reload
sudo systemctl enable --now aneeta-ctf.service

echo "Service installed."
echo "Status: sudo systemctl status aneeta-ctf.service"
