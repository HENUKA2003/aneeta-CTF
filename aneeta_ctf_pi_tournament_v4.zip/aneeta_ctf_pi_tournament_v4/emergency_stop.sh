#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p runtime
touch runtime/STOP_AUTOMATION
echo "Emergency stop enabled: runtime/STOP_AUTOMATION"
