from __future__ import annotations

import os
from pathlib import Path

from flask import Flask, redirect, render_template, request, url_for
from werkzeug.utils import secure_filename

from aneeta.autopilot.engine import AutopilotEngine
from aneeta.autopilot.evidence_reviewer import EvidenceReviewer, format_review
from aneeta.categories import (
    analyze_category_text,
    analyze_forensics_file,
    analyze_web_challenge,
    tool_status,
)
from aneeta.ollama.client import OllamaClient
from aneeta.pipeline import analyze_browser_capture, run_scoped_recon
from aneeta.plugins.registry import SolverRegistry
from aneeta.replay.engine import ReplayEngine
from aneeta.replay.scoreboard import Scoreboard
from aneeta.replay.submission_queue import SubmissionQueue
from aneeta.services.history import HistoryStore

BASE_DIR = Path(__file__).resolve().parent
RUNTIME_DIR = BASE_DIR / "runtime"
UPLOAD_DIR = RUNTIME_DIR / "uploads"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 50 * 1024 * 1024
app.secret_key = os.getenv("ANEETA_SECRET_KEY", os.urandom(32))

history = HistoryStore(RUNTIME_DIR / "logs" / "history.jsonl")
registry = SolverRegistry()
ollama_client = OllamaClient(
    base_url=os.getenv("OLLAMA_URL", "http://127.0.0.1:11434"),
    model=os.getenv("OLLAMA_MODEL", "llama3.2:1b"),
    timeout=int(os.getenv("OLLAMA_TIMEOUT", "120")),
    keep_alive=os.getenv("OLLAMA_KEEP_ALIVE", "10m"),
)
autopilot = AutopilotEngine(
    client=ollama_client,
    registry=registry,
    max_rounds=int(os.getenv("AUTOPILOT_MAX_ROUNDS", "3")),
)
reviewer = EvidenceReviewer(ollama_client)
scoreboard = Scoreboard(RUNTIME_DIR / "score" / "scoreboard.json")
submissions = SubmissionQueue(RUNTIME_DIR / "submissions" / "queue.json")
replay = ReplayEngine(
    BASE_DIR / "replay_packs",
    registry,
    scoreboard,
    submissions,
)


def empty_result(error: str | None = None) -> dict:
    return {
        "error": error,
        "flags": [],
        "steps": [],
        "reports": [],
        "ai_summary": "",
        "action": "",
        "category": "",
        "autopilot": None,
        "replay": None,
    }


def render_page(result=None):
    plugins = registry.describe()
    counts = {}
    for item in plugins:
        counts[item["category"]] = counts.get(item["category"], 0) + 1

    return render_template(
        "index.html",
        result=result,
        plugins=plugins,
        category_counts=counts,
        replay_challenges=replay.challenges(),
        scoreboard=scoreboard.snapshot(),
        submissions=submissions.latest(12),
        history=history.latest(8),
        ollama_status=ollama_client.status(),
        tool_status=tool_status(),
        tournament_stop_active=(RUNTIME_DIR / 'STOP_AUTOMATION').exists(),
        adapter_files=sorted(path.name for path in (BASE_DIR / 'adapters').glob('*.json')),
    )


def save_upload(uploaded) -> tuple[Path, str]:
    if not uploaded or not uploaded.filename:
        raise ValueError("Attachment එකක් select කරන්න.")

    safe_name = secure_filename(uploaded.filename) or "attachment.bin"
    path = UPLOAD_DIR / safe_name
    counter = 1
    while path.exists():
        path = UPLOAD_DIR / f"{counter}_{safe_name}"
        counter += 1
    uploaded.save(path)
    return path, safe_name


def queue_flags(flags: list[str], title: str, challenge_id: str) -> None:
    for flag in flags:
        submissions.add(
            challenge_id=challenge_id,
            challenge_title=title,
            flag=flag,
            platform="manual",
        )


def log_result(action: str, result: dict) -> None:
    history.append({
        "action": action,
        "flags": result.get("flags", []),
        "reports": result.get("reports", []),
        "status": "error" if result.get("error") else "ok",
        **({"error": result["error"]} if result.get("error") else {}),
    })


@app.get("/")
def index():
    return render_page()


@app.post("/lab/text")
def text_lab():
    result = empty_result()
    category = request.form.get("category", "").strip().lower()
    result["action"] = f"{category}_lab"
    result["category"] = category

    try:
        text = request.form.get("challenge_text", "").strip()
        flag_format = request.form.get("flag_format", "").strip()
        if not text:
            raise ValueError("Challenge text එක paste කරන්න.")

        part = analyze_category_text(text, category, flag_format, registry)
        result["flags"] = part["flags"]
        result["steps"] = part["steps"]
        result["reports"] = part["reports"]

        if request.form.get("ollama_review") == "on":
            result["ai_summary"] = format_review(reviewer.review(
                category=category,
                challenge_context=text,
                flags=result["flags"],
                reports=result["reports"],
                steps=result["steps"],
            ))

        queue_flags(
            result["flags"],
            f"{category.title()} Lab Result",
            f"{category}-lab",
        )
    except Exception as exc:
        result["error"] = str(exc)

    log_result(result["action"], result)
    return render_page(result)


@app.post("/lab/web")
def web_lab():
    result = empty_result()
    result["action"] = "web_lab"
    result["category"] = "web"

    try:
        url = request.form.get("challenge_url", "").strip()
        if not url:
            raise ValueError("Authorized CTF URL එක දෙන්න.")

        part = analyze_web_challenge(
            url=url,
            flag_format=request.form.get("flag_format", "").strip(),
            allow_private=request.form.get("allow_private") == "on",
            registry=registry,
        )
        result["flags"] = part["flags"]
        result["steps"] = part["steps"]
        result["reports"] = part["reports"]

        if request.form.get("ollama_review") == "on":
            result["ai_summary"] = format_review(reviewer.review(
                category="web",
                challenge_context=url,
                flags=result["flags"],
                reports=result["reports"],
                steps=result["steps"],
            ))

        queue_flags(result["flags"], "Web Lab Result", "web-lab")
    except Exception as exc:
        result["error"] = str(exc)

    log_result("web_lab", result)
    return render_page(result)


@app.post("/lab/forensics")
def forensics_lab():
    result = empty_result()
    result["action"] = "forensics_lab"
    result["category"] = "forensics"
    path = None

    try:
        path, name = save_upload(request.files.get("attachment"))
        part = analyze_forensics_file(
            path=path,
            original_name=name,
            flag_format=request.form.get("flag_format", "").strip(),
        )
        result["flags"] = part["flags"]
        result["steps"] = part["steps"]
        result["reports"] = part["reports"]

        if request.form.get("ollama_review") == "on":
            result["ai_summary"] = format_review(reviewer.review(
                category="forensics",
                challenge_context=f"Uploaded file: {name}",
                flags=result["flags"],
                reports=result["reports"],
                steps=result["steps"],
            ))

        queue_flags(result["flags"], f"Forensics: {name}", "forensics-lab")
    except Exception as exc:
        result["error"] = str(exc)
    finally:
        if path and path.exists():
            path.unlink(missing_ok=True)

    log_result("forensics_lab", result)
    return render_page(result)


@app.post("/autopilot")
def run_autopilot():
    result = empty_result()
    result["action"] = "autopilot"

    try:
        text = request.form.get("challenge_text", "").strip()
        if not text:
            raise ValueError("Autopilot එකට challenge text එක paste කරන්න.")

        solved = autopilot.run(
            challenge_text=text,
            flag_format=request.form.get("flag_format", "").strip(),
        )
        result["flags"] = solved["flags"]
        result["autopilot"] = solved
        result["category"] = solved["plan"].get("category", "")
        result["reports"] = [{
            "kind": "autopilot",
            "title": "Ollama Autopilot",
            "data": {
                "plan": solved["plan"],
                "rounds": solved["rounds"],
                "ollama_status": solved["ollama_status"],
            },
        }]
        for finding in solved["findings"][:100]:
            result["steps"].append({
                "title": (
                    f"{finding['plugin_name']} "
                    f"(depth {finding['depth']}, "
                    f"confidence {finding['confidence']:.2f})"
                ),
                "output": (
                    f"{finding['explanation']}\n"
                    f"Chain: {' -> '.join(finding['chain'])}\n\n"
                    f"{finding['output']}"
                ),
                "severity": "info",
            })
        queue_flags(result["flags"], "Ollama Autopilot", "autopilot")
    except Exception as exc:
        result["error"] = str(exc)

    log_result("autopilot", result)
    return render_page(result)


@app.post("/replay")
def replay_challenge():
    result = empty_result()
    result["action"] = "replay"

    try:
        challenge_id = request.form.get("challenge_id", "").strip()
        if not challenge_id:
            raise ValueError("Replay challenge එක select කරන්න.")

        solved = replay.solve(challenge_id)
        result["replay"] = solved
        result["flags"] = solved["flags"]
        result["category"] = solved["challenge"].get("category", "")
        result["reports"] = [{
            "kind": "replay",
            "title": solved["challenge"]["title"],
            "data": {
                "category": solved["challenge"].get("category"),
                "points": solved["challenge"].get("points"),
                "verified": solved["verified"],
                "score": solved["score"],
            },
        }]
        for finding in solved["findings"][:60]:
            result["steps"].append({
                "title": (
                    f"{finding['plugin_name']} "
                    f"(depth {finding['depth']}, "
                    f"confidence {finding['confidence']:.2f})"
                ),
                "output": (
                    f"{finding['explanation']}\n"
                    f"Chain: {' -> '.join(finding['chain'])}\n\n"
                    f"{finding['output']}"
                ),
                "severity": "info",
            })
    except Exception as exc:
        result["error"] = str(exc)

    log_result("replay", result)
    return render_page(result)


@app.post("/browser")
def browser_analysis():
    result = empty_result()
    result["action"] = "browser"
    result["category"] = "web"

    try:
        part = analyze_browser_capture(
            flag_format=request.form.get("flag_format", "").strip()
        )
        result["flags"] = part["flags"]
        result["steps"] = part["steps"]
        result["reports"] = part["reports"]
        queue_flags(result["flags"], "Browser Capture", "browser-capture")
    except Exception as exc:
        result["error"] = str(exc)

    log_result("browser", result)
    return render_page(result)


@app.post("/recon")
def recon():
    result = empty_result()
    result["action"] = "recon"
    result["category"] = "web"

    try:
        target = request.form.get("target", "").strip()
        authorized = request.form.get("authorized") == "on"
        if not target or not authorized:
            raise ValueError("Exact target සහ authorization confirmation එක දෙන්න.")

        part = run_scoped_recon(
            target=target,
            flag_format=request.form.get("flag_format", "").strip(),
            authorized=True,
        )
        result["flags"] = part["flags"]
        result["steps"] = part["steps"]
        result["reports"] = part["reports"]
    except Exception as exc:
        result["error"] = str(exc)

    log_result("recon", result)
    return render_page(result)


@app.post("/tournament/stop")
def tournament_stop():
    stop_file = RUNTIME_DIR / "STOP_AUTOMATION"
    stop_file.touch()
    return redirect(url_for("index"))


@app.post("/tournament/clear-stop")
def tournament_clear_stop():
    stop_file = RUNTIME_DIR / "STOP_AUTOMATION"
    stop_file.unlink(missing_ok=True)
    return redirect(url_for("index"))


@app.errorhandler(413)
def too_large(_error):
    return render_page(
        empty_result("File එක 50 MB limit එකට වඩා විශාලයි.")
    ), 413


if __name__ == "__main__":
    app.run(
        host=os.getenv("ANEETA_BIND", "0.0.0.0"),
        port=int(os.getenv("ANEETA_PORT", "5000")),
        debug=False,
    )
