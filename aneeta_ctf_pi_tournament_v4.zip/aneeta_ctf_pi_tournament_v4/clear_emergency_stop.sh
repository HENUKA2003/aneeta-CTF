#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
rm -f runtime/STOP_AUTOMATION
echo "Emergency stop cleared."
