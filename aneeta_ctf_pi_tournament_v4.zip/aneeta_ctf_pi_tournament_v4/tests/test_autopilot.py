import unittest

from aneeta.autopilot.engine import AutopilotEngine
from aneeta.plugins.registry import SolverRegistry


class FakeClient:
    def chat_structured(self, *, system, user, schema, temperature=0.1):
        if "selected_plugins" in schema["properties"] and "category" in schema["properties"]:
            return {
                "category": "encoding",
                "selected_plugins": ["encoding.base64", "not.allowed"],
                "max_depth": 3,
                "summary": "Use Base64.",
                "confidence": 0.9,
            }
        return {
            "stop": True,
            "selected_plugins": [],
            "summary": "Flag found.",
            "confidence": 0.95,
        }

    def status(self):
        return {
            "online": True,
            "model": "fake",
            "model_available": True,
            "models": ["fake"],
            "error": "",
        }


class AutopilotTests(unittest.TestCase):
    def test_allowlist_and_flag(self):
        engine = AutopilotEngine(
            client=FakeClient(),
            registry=SolverRegistry(),
            max_rounds=2,
        )
        result = engine.run(
            "TGVnaW9ue29sbGFtYV9hdXRvcGlsb3R9",
            "Legion{...}",
        )
        self.assertEqual(result["flags"], ["Legion{ollama_autopilot}"])
        self.assertEqual(
            result["plan"]["selected_plugins"],
            ["encoding.base64"],
        )


if __name__ == "__main__":
    unittest.main()
