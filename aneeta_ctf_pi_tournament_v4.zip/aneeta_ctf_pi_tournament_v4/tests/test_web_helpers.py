import unittest

from aneeta.categories.web_lab import extract_js_endpoints, same_origin


class WebHelperTests(unittest.TestCase):
    def test_endpoint_extraction(self):
        endpoints = extract_js_endpoints(
            'fetch("/api/flag"); const x="/assets/app.js";'
        )
        self.assertIn("/api/flag", endpoints)

    def test_same_origin(self):
        self.assertTrue(
            same_origin(
                "https://ctf.example/challenge",
                "https://ctf.example/robots.txt",
            )
        )
        self.assertFalse(
            same_origin(
                "https://ctf.example/challenge",
                "https://other.example/",
            )
        )


if __name__ == "__main__":
    unittest.main()
