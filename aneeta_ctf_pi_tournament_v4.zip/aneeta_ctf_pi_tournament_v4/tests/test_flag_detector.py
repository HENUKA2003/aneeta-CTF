import unittest

from aneeta.solvers.flag_detector import find_flags


class FlagDetectorTests(unittest.TestCase):
    def test_default_flag(self):
        self.assertEqual(
            find_flags("hello Legion{sample_flag}"),
            ["Legion{sample_flag}"],
        )

    def test_custom_flag(self):
        self.assertEqual(
            find_flags("ACME{abc123}", "ACME{...}"),
            ["ACME{abc123}"],
        )


if __name__ == "__main__":
    unittest.main()
