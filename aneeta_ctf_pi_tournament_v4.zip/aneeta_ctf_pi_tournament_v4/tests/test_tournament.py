import json
import tempfile
import unittest
from pathlib import Path

from aneeta.tournament.candidates import rank_flag_candidates
from aneeta.tournament.config import AdapterConfigError, load_adapter
from aneeta.tournament.scope import ScopeViolation, assert_allowed_url


VALID = {
    "name": "Test",
    "automation_permitted": False,
    "allowed_origins": ["https://ctf.example"],
    "start_url": "https://ctf.example/challenge/1",
    "manual_login_url": "https://ctf.example/login",
    "profile_dir": "runtime/tournament_profiles/test",
    "flag_format": "CTF{...}",
    "selectors": {
        "challenge_title": "h1",
        "challenge_text": "#text",
        "flag_input": "#flag",
        "submit_button": "#submit",
        "correct_marker": ".correct",
        "incorrect_marker": ".incorrect",
        "next_link": ".next",
    },
    "limits": {
        "max_challenges": 10,
        "max_attempts_per_challenge": 3,
        "min_confidence": 0.9,
        "delay_seconds": 5,
        "stop_after_rejections": 5,
    },
}


class TournamentTests(unittest.TestCase):
    def write_config(self, payload):
        temp = tempfile.TemporaryDirectory()
        path = Path(temp.name) / "adapter.json"
        path.write_text(json.dumps(payload), encoding="utf-8")
        return temp, path

    def test_valid_adapter(self):
        temp, path = self.write_config(VALID)
        try:
            config = load_adapter(path)
            self.assertEqual(config.allowed_origins, ("https://ctf.example",))
        finally:
            temp.cleanup()

    def test_wildcard_rejected(self):
        payload = dict(VALID)
        payload["allowed_origins"] = ["https://*.example.com"]
        temp, path = self.write_config(payload)
        try:
            with self.assertRaises(AdapterConfigError):
                load_adapter(path)
        finally:
            temp.cleanup()

    def test_scope_guard(self):
        assert_allowed_url(
            "https://ctf.example/challenge/2",
            ("https://ctf.example",),
        )
        with self.assertRaises(ScopeViolation):
            assert_allowed_url(
                "https://other.example/challenge/2",
                ("https://ctf.example",),
            )

    def test_candidate_ranking(self):
        candidates = rank_flag_candidates(
            "Decode this value.",
            [{
                "plugin_id": "encoding.base64",
                "plugin_name": "Base64",
                "output": "CTF{ranked}",
                "confidence": 0.96,
            }],
            "CTF{...}",
        )
        self.assertEqual(candidates[0]["flag"], "CTF{ranked}")
        self.assertGreaterEqual(candidates[0]["confidence"], 0.96)


if __name__ == "__main__":
    unittest.main()
