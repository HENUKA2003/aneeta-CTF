import tempfile
import unittest
from pathlib import Path
import json

from aneeta.plugins.registry import SolverRegistry
from aneeta.replay.engine import ReplayEngine
from aneeta.replay.scoreboard import Scoreboard
from aneeta.replay.submission_queue import SubmissionQueue


class ReplayTests(unittest.TestCase):
    def test_points_awarded_once(self):
        with tempfile.TemporaryDirectory() as temp:
            base = Path(temp)
            packs = base / "packs"
            packs.mkdir()
            (packs / "pack.json").write_text(json.dumps({
                "pack_name": "test",
                "challenges": [{
                    "id": "one",
                    "title": "One",
                    "points": 20,
                    "input": "TGVnaW9ue3Rlc3R9",
                    "flag_format": "Legion{...}",
                    "expected_flag": "Legion{test}"
                }]
            }), encoding="utf-8")

            engine = ReplayEngine(
                packs,
                SolverRegistry(),
                Scoreboard(base / "score.json"),
                SubmissionQueue(base / "queue.json"),
            )

            first = engine.solve("one")
            second = engine.solve("one")

            self.assertTrue(first["score"]["awarded"])
            self.assertFalse(second["score"]["awarded"])
            self.assertEqual(second["score"]["total_points"], 20)


if __name__ == "__main__":
    unittest.main()
