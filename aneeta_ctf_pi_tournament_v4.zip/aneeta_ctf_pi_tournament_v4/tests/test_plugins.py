import unittest

from aneeta.plugins.registry import SolverRegistry


class PluginTests(unittest.TestCase):
    def setUp(self):
        self.registry = SolverRegistry()

    def test_recursive_layered_decode(self):
        results = self.registry.solve_recursive(
            "5447566e6157397565334a6c634778686556397359586c6c636d566b66513d3d",
            max_depth=5,
        )
        outputs = [item["output"] for item in results]
        self.assertIn("Legion{replay_layered}", outputs)


if __name__ == "__main__":
    unittest.main()
