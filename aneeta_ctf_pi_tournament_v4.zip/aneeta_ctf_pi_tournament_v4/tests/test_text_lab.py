import unittest

from aneeta.categories.text_lab import analyze_category_text
from aneeta.plugins.registry import SolverRegistry


class TextLabTests(unittest.TestCase):
    def test_crypto_lab(self):
        result = analyze_category_text(
            "TGVnaW9ue2NyeXB0b19sYWJ9",
            "crypto",
            "Legion{...}",
            SolverRegistry(),
        )
        self.assertIn("Legion{crypto_lab}", result["flags"])

    def test_misc_lab(self):
        result = analyze_category_text(
            "67 84 70 123 65 125",
            "misc",
            "CTF{...}",
            SolverRegistry(),
        )
        self.assertIn("CTF{A}", result["flags"])


if __name__ == "__main__":
    unittest.main()
