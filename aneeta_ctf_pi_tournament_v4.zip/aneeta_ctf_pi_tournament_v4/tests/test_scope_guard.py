import unittest

from aneeta.security.scope_guard import validate_authorized_target


class ScopeGuardTests(unittest.TestCase):
    def test_ip_requires_authorization(self):
        with self.assertRaises(ValueError):
            validate_authorized_target("10.10.10.10", authorized=False)

    def test_ip_allowed_with_authorization(self):
        self.assertEqual(
            validate_authorized_target("10.10.10.10", authorized=True),
            "10.10.10.10",
        )

    def test_cidr_rejected(self):
        with self.assertRaises(ValueError):
            validate_authorized_target("10.10.10.0/24", authorized=True)


if __name__ == "__main__":
    unittest.main()
