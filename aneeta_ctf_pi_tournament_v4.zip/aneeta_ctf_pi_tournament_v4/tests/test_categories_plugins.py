import unittest

from aneeta.plugins.registry import SolverRegistry


class CategoryPluginTests(unittest.TestCase):
    def setUp(self):
        self.registry = SolverRegistry()

    def outputs(self, value, plugin_ids):
        results = self.registry.solve_recursive(
            value, max_depth=5, plugin_ids=plugin_ids
        )
        return [item["output"] for item in results]

    def test_atbash(self):
        self.assertIn(
            "Legion{category}",
            self.outputs("Ovtrlm{xzgvtlib}", ["cipher.atbash"]),
        )

    def test_decimal_ascii(self):
        self.assertIn(
            "CTF{A}",
            self.outputs(
                "67 84 70 123 65 125",
                ["encoding.decimal_ascii"],
            ),
        )

    def test_single_byte_xor(self):
        plaintext = b"Legion{xor_test}"
        ciphertext = bytes(byte ^ 0x23 for byte in plaintext).hex()
        self.assertIn(
            "Legion{xor_test}",
            self.outputs(ciphertext, ["cipher.single_byte_xor"]),
        )

    def test_jwt_decode(self):
        token = (
            "eyJhbGciOiJub25lIiwidHlwIjoiSldUIn0."
            "eyJmbGFnIjoiTGVnaW9ue2p3dF9pbnNwZWN0b3J9In0."
        )
        outputs = self.outputs(token, ["web.jwt_decode"])
        self.assertTrue(any("Legion{jwt_inspector}" in item for item in outputs))


if __name__ == "__main__":
    unittest.main()
