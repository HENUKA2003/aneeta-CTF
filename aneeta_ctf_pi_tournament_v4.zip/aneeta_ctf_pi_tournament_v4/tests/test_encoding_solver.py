import unittest

from aneeta.solvers.encoding_solver import analyze_encodings


class EncodingSolverTests(unittest.TestCase):
    def test_base64(self):
        steps, outputs = analyze_encodings(
            "TGVnaW9ue3Rlc3RfZmxhZ30="
        )
        self.assertIn("Legion{test_flag}", outputs)

    def test_hex(self):
        _steps, outputs = analyze_encodings("666c61677b6869787d")
        self.assertIn("flag{hix}", outputs)


if __name__ == "__main__":
    unittest.main()
