from __future__ import annotations

import base64
import binascii
import codecs
import html
import re
from urllib.parse import unquote_plus

from aneeta.models import Step


MORSE = {
    ".-": "A", "-...": "B", "-.-.": "C", "-..": "D", ".": "E",
    "..-.": "F", "--.": "G", "....": "H", "..": "I", ".---": "J",
    "-.-": "K", ".-..": "L", "--": "M", "-.": "N", "---": "O",
    ".--.": "P", "--.-": "Q", ".-.": "R", "...": "S", "-": "T",
    "..-": "U", "...-": "V", ".--": "W", "-..-": "X", "-.--": "Y",
    "--..": "Z", "-----": "0", ".----": "1", "..---": "2",
    "...--": "3", "....-": "4", ".....": "5", "-....": "6",
    "--...": "7", "---..": "8", "----.": "9",
}


def printable(text: str) -> bool:
    if not text:
        return False
    count = sum(ch.isprintable() or ch in "\r\n\t" for ch in text)
    return count / len(text) >= 0.85


def add(
    steps: list[dict],
    outputs: list[str],
    title: str,
    value: str,
) -> None:
    value = value.strip()
    if not value or not printable(value):
        return
    if value in outputs:
        return
    outputs.append(value)
    steps.append(Step(title, value[:12000]).to_dict())


def decode_morse(value: str) -> str:
    words = re.split(r"\s*/\s*|\s{3,}", value.strip())
    decoded_words = []
    for word in words:
        letters = []
        for token in word.split():
            if token not in MORSE:
                return ""
            letters.append(MORSE[token])
        decoded_words.append("".join(letters))
    return " ".join(decoded_words)


def analyze_encodings(value: str) -> tuple[list[dict], list[str]]:
    steps: list[dict] = []
    outputs: list[str] = []
    compact = re.sub(r"\s+", "", value)

    # HTML entities
    decoded_html = html.unescape(value)
    if decoded_html != value:
        add(steps, outputs, "HTML entity decode", decoded_html)

    # URL encoding
    decoded_url = unquote_plus(value)
    if decoded_url != value:
        add(steps, outputs, "URL decode", decoded_url)

    # Base64
    try:
        padded = compact + "=" * (-len(compact) % 4)
        decoded = base64.b64decode(padded, validate=True).decode("utf-8")
        add(steps, outputs, "Base64 decode", decoded)
    except (ValueError, UnicodeDecodeError, binascii.Error):
        pass

    # URL-safe Base64
    try:
        padded = compact + "=" * (-len(compact) % 4)
        decoded = base64.urlsafe_b64decode(padded).decode("utf-8")
        if decoded != value:
            add(steps, outputs, "URL-safe Base64 decode", decoded)
    except (ValueError, UnicodeDecodeError, binascii.Error):
        pass

    # Base32
    try:
        padded = compact.upper() + "=" * (-len(compact) % 8)
        decoded = base64.b32decode(padded, casefold=True).decode("utf-8")
        add(steps, outputs, "Base32 decode", decoded)
    except (ValueError, UnicodeDecodeError, binascii.Error):
        pass

    # Hex
    if compact and re.fullmatch(r"[0-9a-fA-F]+", compact) and len(compact) % 2 == 0:
        try:
            add(
                steps,
                outputs,
                "Hex decode",
                bytes.fromhex(compact).decode("utf-8"),
            )
        except (ValueError, UnicodeDecodeError):
            pass

    # Binary
    if compact and re.fullmatch(r"[01]+", compact) and len(compact) % 8 == 0:
        try:
            decoded = "".join(
                chr(int(compact[index:index + 8], 2))
                for index in range(0, len(compact), 8)
            )
            add(steps, outputs, "Binary decode", decoded)
        except ValueError:
            pass

    # ROT13
    try:
        decoded = codecs.decode(value, "rot_13")
        if decoded != value:
            add(steps, outputs, "ROT13 decode", decoded)
    except Exception:
        pass

    # Morse
    if re.fullmatch(r"[\s./-]+", value.strip()):
        decoded = decode_morse(value)
        if decoded:
            add(steps, outputs, "Morse decode", decoded)

    # Caesar brute force, shown only when braces appear.
    lower = "abcdefghijklmnopqrstuvwxyz"
    upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    for shift in range(1, 26):
        chars = []
        for char in value:
            if char in lower:
                chars.append(lower[(lower.index(char) - shift) % 26])
            elif char in upper:
                chars.append(upper[(upper.index(char) - shift) % 26])
            else:
                chars.append(char)
        decoded = "".join(chars)
        if "{" in decoded and "}" in decoded:
            add(steps, outputs, f"Caesar shift {shift}", decoded)

    return steps, outputs
