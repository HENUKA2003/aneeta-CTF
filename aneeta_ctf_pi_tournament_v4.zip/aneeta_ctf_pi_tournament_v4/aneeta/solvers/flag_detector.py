from __future__ import annotations

import re


DEFAULT_PATTERNS = [
    r"picoCTF\{[^}\r\n]{1,300}\}",
    r"THM\{[^}\r\n]{1,300}\}",
    r"HTB\{[^}\r\n]{1,300}\}",
    r"Legion\{[^}\r\n]{1,300}\}",
    r"flag\{[^}\r\n]{1,300}\}",
    r"CTF\{[^}\r\n]{1,300}\}",
]


def custom_pattern(custom_format: str) -> str | None:
    value = custom_format.strip()
    if not value:
        return None

    if "{...}" in value:
        prefix = re.escape(value.replace("{...}", ""))
        return rf"{prefix}\{{[^}}\r\n]{{1,300}}\}}"

    if value.endswith("{}"):
        prefix = re.escape(value[:-2])
        return rf"{prefix}\{{[^}}\r\n]{{1,300}}\}}"

    return None


def find_flags(text: str, custom_format: str = "") -> list[str]:
    patterns = list(DEFAULT_PATTERNS)
    custom = custom_pattern(custom_format)
    if custom:
        patterns.insert(0, custom)

    found: list[str] = []
    for pattern in patterns:
        for match in re.findall(pattern, text, flags=re.IGNORECASE):
            if match not in found:
                found.append(match)
    return found
