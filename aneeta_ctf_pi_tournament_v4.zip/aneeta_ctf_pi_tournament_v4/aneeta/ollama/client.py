from __future__ import annotations

from dataclasses import dataclass
import json
from typing import Any

import requests


class OllamaError(RuntimeError):
    pass


@dataclass
class OllamaClient:
    base_url: str = "http://127.0.0.1:11434"
    model: str = "llama3.2:1b"
    timeout: int = 120
    keep_alive: str = "10m"

    def __post_init__(self) -> None:
        self.base_url = self.base_url.rstrip("/")

    def status(self) -> dict[str, Any]:
        try:
            response = requests.get(
                f"{self.base_url}/api/tags",
                timeout=5,
            )
            response.raise_for_status()
            payload = response.json()
        except Exception as exc:
            return {
                "online": False,
                "model": self.model,
                "models": [],
                "error": str(exc),
            }

        models = [
            str(item.get("name", ""))
            for item in payload.get("models", [])
            if item.get("name")
        ]
        available = (
            self.model in models
            or any(name.split(":", 1)[0] == self.model for name in models)
        )
        return {
            "online": True,
            "model": self.model,
            "model_available": available,
            "models": models,
            "error": "",
        }

    def chat_structured(
        self,
        *,
        system: str,
        user: str,
        schema: dict[str, Any],
        temperature: float = 0.1,
    ) -> dict[str, Any]:
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "format": schema,
            "stream": False,
            "think": False,
            "keep_alive": self.keep_alive,
            "options": {
                "temperature": temperature,
                "num_ctx": 4096,
            },
        }

        try:
            response = requests.post(
                f"{self.base_url}/api/chat",
                json=payload,
                timeout=self.timeout,
            )
            response.raise_for_status()
            data = response.json()
            content = str(data["message"]["content"])
            result = json.loads(content)
        except requests.RequestException as exc:
            raise OllamaError(f"Ollama request failed: {exc}") from exc
        except (KeyError, TypeError, json.JSONDecodeError) as exc:
            raise OllamaError("Ollama returned invalid structured output.") from exc

        if not isinstance(result, dict):
            raise OllamaError("Ollama structured output was not an object.")
        return result
