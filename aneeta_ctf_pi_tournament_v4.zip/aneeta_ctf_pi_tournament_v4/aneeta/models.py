from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any


@dataclass
class Step:
    title: str
    output: str
    severity: str = "info"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class Report:
    kind: str
    title: str
    data: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
