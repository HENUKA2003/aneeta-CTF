from __future__ import annotations

from datetime import datetime, timezone
import json
from pathlib import Path


class Scoreboard:
    def __init__(self, path: Path):
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def _load(self) -> dict:
        if not self.path.exists():
            return {"total_points": 0, "solved": {}}

        try:
            return json.loads(self.path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return {"total_points": 0, "solved": {}}

    def _save(self, state: dict) -> None:
        temporary = self.path.with_suffix(".tmp")
        temporary.write_text(
            json.dumps(state, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        temporary.replace(self.path)

    def award(
        self,
        challenge_id: str,
        title: str,
        points: int,
        flag: str,
    ) -> dict:
        state = self._load()
        already_solved = challenge_id in state["solved"]

        if not already_solved:
            state["solved"][challenge_id] = {
                "title": title,
                "points": points,
                "flag": flag,
                "solved_at": datetime.now(timezone.utc).isoformat(),
            }
            state["total_points"] += points
            self._save(state)

        return {
            "awarded": not already_solved,
            "total_points": state["total_points"],
            "solved_count": len(state["solved"]),
        }

    def snapshot(self) -> dict:
        return self._load()
