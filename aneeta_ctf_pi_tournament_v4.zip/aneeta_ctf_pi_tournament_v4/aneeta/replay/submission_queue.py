from __future__ import annotations

from datetime import datetime, timezone
import json
from pathlib import Path
import secrets


class SubmissionQueue:
    def __init__(self, path: Path):
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def _load(self) -> list[dict]:
        if not self.path.exists():
            return []
        try:
            return json.loads(self.path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return []

    def _save(self, items: list[dict]) -> None:
        temporary = self.path.with_suffix(".tmp")
        temporary.write_text(
            json.dumps(items, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        temporary.replace(self.path)

    def add(
        self,
        challenge_id: str,
        challenge_title: str,
        flag: str,
        platform: str = "local-replay",
    ) -> dict:
        items = self._load()

        for item in items:
            if (
                item["challenge_id"] == challenge_id
                and item["flag"] == flag
                and item["status"] == "pending"
            ):
                return item

        item = {
            "id": secrets.token_hex(6),
            "challenge_id": challenge_id,
            "challenge_title": challenge_title,
            "flag": flag,
            "platform": platform,
            "status": "pending",
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        items.append(item)
        self._save(items)
        return item

    def latest(self, limit: int = 20) -> list[dict]:
        return list(reversed(self._load()[-limit:]))
