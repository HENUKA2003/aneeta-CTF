from __future__ import annotations

import json
from pathlib import Path

from aneeta.plugins.registry import SolverRegistry
from aneeta.replay.scoreboard import Scoreboard
from aneeta.replay.submission_queue import SubmissionQueue
from aneeta.solvers.flag_detector import find_flags


class ReplayEngine:
    def __init__(
        self,
        packs_dir: Path,
        registry: SolverRegistry,
        scoreboard: Scoreboard,
        submissions: SubmissionQueue,
    ):
        self.packs_dir = packs_dir
        self.registry = registry
        self.scoreboard = scoreboard
        self.submissions = submissions

    def challenges(self) -> list[dict]:
        challenges: list[dict] = []
        for path in sorted(self.packs_dir.glob("*.json")):
            try:
                payload = json.loads(path.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                continue

            for challenge in payload.get("challenges", []):
                item = dict(challenge)
                item["_pack"] = payload.get("pack_name", path.stem)
                challenges.append(item)

        return challenges

    def get(self, challenge_id: str) -> dict:
        for challenge in self.challenges():
            if challenge.get("id") == challenge_id:
                return challenge
        raise ValueError("Replay challenge එක හමු වුණේ නැහැ.")

    def solve(self, challenge_id: str) -> dict:
        challenge = self.get(challenge_id)
        source = str(challenge.get("input", ""))
        flag_format = str(challenge.get("flag_format", ""))
        expected_flag = str(challenge.get("expected_flag", ""))

        findings = self.registry.solve_recursive(
            source,
            max_depth=int(challenge.get("max_depth", 5)),
        )

        searchable = [source]
        searchable.extend(str(item["output"]) for item in findings)
        flags = find_flags(
            "\n".join(searchable),
            custom_format=flag_format,
        )

        solved_flag = ""
        verified = False

        if expected_flag and expected_flag in flags:
            solved_flag = expected_flag
            verified = True
        elif flags and not expected_flag:
            solved_flag = flags[0]

        score = None
        submission = None

        if solved_flag and verified:
            score = self.scoreboard.award(
                challenge_id=str(challenge["id"]),
                title=str(challenge["title"]),
                points=int(challenge.get("points", 0)),
                flag=solved_flag,
            )
            submission = self.submissions.add(
                challenge_id=str(challenge["id"]),
                challenge_title=str(challenge["title"]),
                flag=solved_flag,
            )

        return {
            "challenge": challenge,
            "findings": findings,
            "flags": flags,
            "solved_flag": solved_flag,
            "verified": verified,
            "score": score,
            "submission": submission,
        }
