from __future__ import annotations

import ipaddress
import re
import socket
from urllib.parse import urlparse


HOST_RE = re.compile(
    r"^(?=.{1,253}$)([A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?\.)*"
    r"[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?$"
)


def validate_authorized_target(target: str, authorized: bool) -> str:
    if not authorized:
        raise ValueError("Authorization confirmation එක අවශ්‍යයි.")

    value = target.strip()
    if not value:
        raise ValueError("Target එක හිස්.")

    # Accept an exact IP or hostname only. No CIDR/ranges in the dashboard.
    if "/" in value or " " in value or "," in value:
        raise ValueError("Exact IP address එකක් හෝ hostname එකක් පමණක් දෙන්න.")

    try:
        ipaddress.ip_address(value)
        return value
    except ValueError:
        pass

    if not HOST_RE.fullmatch(value):
        raise ValueError("Invalid hostname.")

    try:
        socket.getaddrinfo(value, None)
    except socket.gaierror as exc:
        raise ValueError(f"Hostname resolve කරන්න බැහැ: {exc}") from exc

    return value
