from __future__ import annotations

from dataclasses import asdict
from typing import Iterable

from aneeta.plugins.base import SolverFinding, SolverPlugin
from aneeta.plugins.builtin import BUILTIN_PLUGINS


class SolverRegistry:
    def __init__(self, plugins: Iterable[SolverPlugin] | None = None):
        self._plugins = list(plugins or BUILTIN_PLUGINS)

    @property
    def plugins(self) -> list[SolverPlugin]:
        return list(self._plugins)

    def describe(self) -> list[dict]:
        return [
            {
                "plugin_id": plugin.plugin_id,
                "name": plugin.name,
                "category": plugin.category,
                "description": plugin.description,
            }
            for plugin in self._plugins
        ]

    def solve_once(
        self,
        value: str,
        plugin_ids: list[str] | None = None,
    ) -> list[SolverFinding]:
        findings: list[SolverFinding] = []
        allowed = set(plugin_ids) if plugin_ids else None
        for plugin in self._plugins:
            if allowed is not None and plugin.plugin_id not in allowed:
                continue
            try:
                findings.extend(plugin.solve(value))
            except Exception:
                continue

        findings.sort(key=lambda item: item.confidence, reverse=True)
        unique: dict[tuple[str, str], SolverFinding] = {}
        for item in findings:
            unique.setdefault((item.plugin_id, item.output), item)
        return list(unique.values())

    def solve_recursive(
        self,
        value: str,
        max_depth: int = 5,
        max_nodes: int = 100,
        plugin_ids: list[str] | None = None,
    ) -> list[dict]:
        queue: list[tuple[str, int, list[str]]] = [(value, 0, [])]
        visited = {value}
        results: list[dict] = []

        while queue and len(visited) <= max_nodes:
            current, depth, chain = queue.pop(0)
            if depth >= max_depth:
                continue

            for finding in self.solve_once(current, plugin_ids=plugin_ids):
                if finding.output in visited:
                    continue

                visited.add(finding.output)
                next_chain = [*chain, finding.plugin_id]
                results.append({
                    **asdict(finding),
                    "depth": depth + 1,
                    "chain": next_chain,
                })
                queue.append((finding.output, depth + 1, next_chain))

        results.sort(
            key=lambda item: (
                -float(item["confidence"]),
                int(item["depth"]),
            )
        )
        return results
