from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol


@dataclass(frozen=True)
class SolverFinding:
    plugin_id: str
    plugin_name: str
    output: str
    confidence: float
    explanation: str


class SolverPlugin(Protocol):
    plugin_id: str
    name: str
    category: str
    description: str

    def solve(self, value: str) -> list[SolverFinding]:
        ...
