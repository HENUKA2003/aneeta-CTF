from __future__ import annotations

import base64
import binascii
import codecs
from datetime import datetime, timezone
import html
import json
import math
import re
import string
from urllib.parse import unquote_plus

from aneeta.plugins.base import SolverFinding


FLAG_WORDS = ("flag", "ctf", "legion", "thm", "pico", "htb")


def printable(value: str) -> bool:
    if not value:
        return False
    count = sum(ch.isprintable() or ch in "\r\n\t" for ch in value)
    return count / len(value) >= 0.85


def english_score(value: str) -> float:
    if not value:
        return 0.0
    lowered = value.lower()
    letters_spaces = sum(ch in string.ascii_lowercase + " " for ch in lowered)
    common = sum(lowered.count(word) for word in (
        " the ", " and ", " flag", "ctf", "this", "that", "you", "{", "}"
    ))
    return (letters_spaces / max(len(value), 1)) + min(common * 0.08, 0.5)


class Base64Plugin:
    plugin_id = "encoding.base64"
    name = "Base64 Decoder"
    category = "encoding"
    description = "Standard and URL-safe Base64 decoding."

    def solve(self, value: str) -> list[SolverFinding]:
        compact = re.sub(r"\s+", "", value)
        if len(compact) < 4:
            return []

        findings: list[SolverFinding] = []
        padded = compact + "=" * (-len(compact) % 4)
        for label, decoder in (
            ("standard", base64.b64decode),
            ("URL-safe", base64.urlsafe_b64decode),
        ):
            try:
                raw = (
                    decoder(padded, validate=True)
                    if label == "standard"
                    else decoder(padded)
                )
                decoded = raw.decode("utf-8")
            except (ValueError, UnicodeDecodeError, binascii.Error):
                continue
            if decoded != value and printable(decoded):
                findings.append(SolverFinding(
                    self.plugin_id,
                    self.name,
                    decoded,
                    0.96 if label == "standard" else 0.90,
                    f"{label} Base64 decode succeeded.",
                ))
        unique = {}
        for item in findings:
            unique.setdefault(item.output, item)
        return list(unique.values())


class Base32Plugin:
    plugin_id = "encoding.base32"
    name = "Base32 Decoder"
    category = "encoding"
    description = "RFC 4648 Base32 decoding."

    def solve(self, value: str) -> list[SolverFinding]:
        compact = re.sub(r"\s+", "", value).upper()
        if len(compact) < 8:
            return []
        try:
            padded = compact + "=" * (-len(compact) % 8)
            decoded = base64.b32decode(padded, casefold=True).decode("utf-8")
        except (ValueError, UnicodeDecodeError, binascii.Error):
            return []
        if decoded == value or not printable(decoded):
            return []
        return [SolverFinding(
            self.plugin_id, self.name, decoded, 0.94,
            "Base32 decode succeeded.",
        )]


class Base85Plugin:
    plugin_id = "encoding.base85"
    name = "Base85 Decoder"
    category = "encoding"
    description = "Ascii85 and RFC 1924 Base85 decoding."

    def solve(self, value: str) -> list[SolverFinding]:
        compact = value.strip()
        if len(compact) < 5:
            return []
        findings = []
        for label, decoder in (
            ("Ascii85", base64.a85decode),
            ("Base85", base64.b85decode),
        ):
            try:
                decoded = decoder(compact.encode()).decode("utf-8")
            except (ValueError, UnicodeDecodeError, binascii.Error):
                continue
            if printable(decoded) and decoded != value:
                findings.append(SolverFinding(
                    self.plugin_id, self.name, decoded, 0.88,
                    f"{label} decode succeeded.",
                ))
        return findings


class HexPlugin:
    plugin_id = "encoding.hex"
    name = "Hex Decoder"
    category = "encoding"
    description = "Hexadecimal text decoding."

    def solve(self, value: str) -> list[SolverFinding]:
        compact = re.sub(r"\s+|0x", "", value, flags=re.IGNORECASE)
        if (
            len(compact) < 2
            or len(compact) % 2
            or not re.fullmatch(r"[0-9a-fA-F]+", compact)
        ):
            return []
        try:
            decoded = bytes.fromhex(compact).decode("utf-8")
        except (ValueError, UnicodeDecodeError):
            return []
        if not printable(decoded):
            return []
        return [SolverFinding(
            self.plugin_id, self.name, decoded, 0.97,
            "Valid hexadecimal text decoded as UTF-8.",
        )]


class BinaryPlugin:
    plugin_id = "encoding.binary"
    name = "Binary Decoder"
    category = "encoding"
    description = "8-bit binary text decoding."

    def solve(self, value: str) -> list[SolverFinding]:
        compact = re.sub(r"\s+", "", value)
        if (
            len(compact) < 8
            or len(compact) % 8
            or not re.fullmatch(r"[01]+", compact)
        ):
            return []
        decoded = "".join(
            chr(int(compact[index:index + 8], 2))
            for index in range(0, len(compact), 8)
        )
        if not printable(decoded):
            return []
        return [SolverFinding(
            self.plugin_id, self.name, decoded, 0.98,
            "Binary octets decoded to printable text.",
        )]


class DecimalAsciiPlugin:
    plugin_id = "encoding.decimal_ascii"
    name = "Decimal ASCII Decoder"
    category = "misc"
    description = "Space/comma-separated decimal ASCII values."

    def solve(self, value: str) -> list[SolverFinding]:
        tokens = re.findall(r"\b\d{1,3}\b", value)
        if len(tokens) < 3 or re.sub(r"[\d,\s]+", "", value).strip():
            return []
        numbers = [int(item) for item in tokens]
        if any(number > 255 for number in numbers):
            return []
        decoded = "".join(chr(number) for number in numbers)
        if not printable(decoded):
            return []
        return [SolverFinding(
            self.plugin_id, self.name, decoded, 0.91,
            "Decimal byte values decoded as ASCII.",
        )]


class OctalAsciiPlugin:
    plugin_id = "encoding.octal_ascii"
    name = "Octal ASCII Decoder"
    category = "misc"
    description = "Space/comma-separated octal ASCII values."

    def solve(self, value: str) -> list[SolverFinding]:
        tokens = re.findall(r"\b[0-7]{2,3}\b", value)
        if len(tokens) < 3 or re.sub(r"[0-7,\s]+", "", value).strip():
            return []
        numbers = [int(item, 8) for item in tokens]
        if any(number > 255 for number in numbers):
            return []
        decoded = "".join(chr(number) for number in numbers)
        if not printable(decoded):
            return []
        return [SolverFinding(
            self.plugin_id, self.name, decoded, 0.89,
            "Octal byte values decoded as ASCII.",
        )]


class Rot13Plugin:
    plugin_id = "cipher.rot13"
    name = "ROT13 Decoder"
    category = "crypto"
    description = "ROT13 substitution."

    def solve(self, value: str) -> list[SolverFinding]:
        if not re.search(r"[A-Za-z]", value):
            return []
        decoded = codecs.decode(value, "rot_13")
        if decoded == value:
            return []
        confidence = 0.92 if "{" in decoded and "}" in decoded else 0.52
        return [SolverFinding(
            self.plugin_id, self.name, decoded, confidence,
            "ROT13 transformation applied.",
        )]


class AtbashPlugin:
    plugin_id = "cipher.atbash"
    name = "Atbash Decoder"
    category = "crypto"
    description = "Alphabet-reversal substitution cipher."

    def solve(self, value: str) -> list[SolverFinding]:
        if not re.search(r"[A-Za-z]", value):
            return []
        lower = str.maketrans(string.ascii_lowercase, string.ascii_lowercase[::-1])
        upper = str.maketrans(string.ascii_uppercase, string.ascii_uppercase[::-1])
        decoded = value.translate(lower).translate(upper)
        confidence = 0.85 if "{" in decoded and "}" in decoded else 0.48
        return [SolverFinding(
            self.plugin_id, self.name, decoded, confidence,
            "Atbash alphabet reversal applied.",
        )]


class CaesarPlugin:
    plugin_id = "cipher.caesar"
    name = "Caesar Brute Force"
    category = "crypto"
    description = "Tests all 25 Caesar shifts and ranks useful outputs."

    def solve(self, value: str) -> list[SolverFinding]:
        lower = string.ascii_lowercase
        upper = string.ascii_uppercase
        candidates = []
        for shift in range(1, 26):
            chars = []
            for char in value:
                if char in lower:
                    chars.append(lower[(lower.index(char) - shift) % 26])
                elif char in upper:
                    chars.append(upper[(upper.index(char) - shift) % 26])
                else:
                    chars.append(char)
            decoded = "".join(chars)
            score = english_score(decoded)
            if "{" in decoded and "}" in decoded:
                score += 0.75
            candidates.append((score, shift, decoded))

        findings = []
        for score, shift, decoded in sorted(candidates, reverse=True)[:5]:
            if score < 0.55 and not ("{" in decoded and "}" in decoded):
                continue
            findings.append(SolverFinding(
                self.plugin_id,
                self.name,
                decoded,
                min(0.94, 0.45 + score / 2),
                f"Caesar shift {shift}; score {score:.2f}.",
            ))
        return findings


class SingleByteXorPlugin:
    plugin_id = "cipher.single_byte_xor"
    name = "Single-byte XOR"
    category = "crypto"
    description = "Brute-forces one-byte XOR keys for hex ciphertext."

    def solve(self, value: str) -> list[SolverFinding]:
        compact = re.sub(r"\s+|0x", "", value, flags=re.IGNORECASE)
        if (
            len(compact) < 6
            or len(compact) % 2
            or not re.fullmatch(r"[0-9a-fA-F]+", compact)
        ):
            return []
        raw = bytes.fromhex(compact)
        candidates = []
        for key in range(256):
            decoded_bytes = bytes(byte ^ key for byte in raw)
            try:
                decoded = decoded_bytes.decode("utf-8")
            except UnicodeDecodeError:
                continue
            if not printable(decoded):
                continue
            score = english_score(decoded)
            if "{" in decoded and "}" in decoded:
                score += 0.8
            if any(word in decoded.lower() for word in FLAG_WORDS):
                score += 0.35
            candidates.append((score, key, decoded))

        findings = []
        for score, key, decoded in sorted(candidates, reverse=True)[:5]:
            if score < 0.70:
                continue
            findings.append(SolverFinding(
                self.plugin_id,
                self.name,
                decoded,
                min(0.96, 0.45 + score / 2),
                f"XOR key 0x{key:02x}; ranked printable output.",
            ))
        return findings


class VigenereKnownKeyPlugin:
    plugin_id = "cipher.vigenere_known_key"
    name = "Vigenere Known-key Decoder"
    category = "crypto"
    description = "Decodes when challenge supplies a Vigenere key."

    def solve(self, value: str) -> list[SolverFinding]:
        key_match = re.search(
            r"(?:key|password)\s*[:=]\s*([A-Za-z]+)",
            value,
            flags=re.IGNORECASE,
        )
        cipher_match = re.search(
            r"(?:cipher(?:text)?|message)\s*[:=]\s*([A-Za-z{}\s_-]+)",
            value,
            flags=re.IGNORECASE,
        )
        if not key_match or not cipher_match:
            return []
        key = key_match.group(1).lower()
        ciphertext = cipher_match.group(1)
        output = []
        key_index = 0
        for char in ciphertext:
            if char.isalpha():
                base = ord("A") if char.isupper() else ord("a")
                shift = ord(key[key_index % len(key)]) - ord("a")
                output.append(chr((ord(char) - base - shift) % 26 + base))
                key_index += 1
            else:
                output.append(char)
        decoded = "".join(output)
        return [SolverFinding(
            self.plugin_id, self.name, decoded, 0.93,
            f"Decoded with supplied key `{key}`.",
        )]


class RsaSmallNPlugin:
    plugin_id = "crypto.rsa_small_n"
    name = "RSA Small-N Solver"
    category = "crypto"
    description = "Factors deliberately small RSA moduli up to 128 bits."

    def solve(self, value: str) -> list[SolverFinding]:
        values = {}
        for name in ("n", "e", "c"):
            match = re.search(
                rf"\b{name}\s*[:=]\s*(\d+)",
                value,
                flags=re.IGNORECASE,
            )
            if match:
                values[name] = int(match.group(1))
        if set(values) != {"n", "e", "c"}:
            return []
        n, e, c = values["n"], values["e"], values["c"]
        if n.bit_length() > 128 or n < 4:
            return []
        try:
            from sympy import factorint
            factors = factorint(n, limit=1_000_000)
        except Exception:
            return []
        expanded = []
        for prime, power in factors.items():
            expanded.extend([int(prime)] * int(power))
        if len(expanded) != 2 or expanded[0] * expanded[1] != n:
            return []
        p, q = expanded
        phi = (p - 1) * (q - 1)
        if math.gcd(e, phi) != 1:
            return []
        try:
            d = pow(e, -1, phi)
        except ValueError:
            return []
        message_int = pow(c, d, n)
        length = max(1, (message_int.bit_length() + 7) // 8)
        raw = message_int.to_bytes(length, "big")
        try:
            decoded = raw.decode("utf-8")
        except UnicodeDecodeError:
            return []
        if not printable(decoded):
            return []
        return [SolverFinding(
            self.plugin_id, self.name, decoded, 0.97,
            f"Factored n into p={p}, q={q}, then decrypted RSA.",
        )]


class MorsePlugin:
    plugin_id = "encoding.morse"
    name = "Morse Decoder"
    category = "misc"
    description = "Morse code with spaces and slash-separated words."

    TABLE = {
        ".-": "A", "-...": "B", "-.-.": "C", "-..": "D", ".": "E",
        "..-.": "F", "--.": "G", "....": "H", "..": "I", ".---": "J",
        "-.-": "K", ".-..": "L", "--": "M", "-.": "N", "---": "O",
        ".--.": "P", "--.-": "Q", ".-.": "R", "...": "S", "-": "T",
        "..-": "U", "...-": "V", ".--": "W", "-..-": "X", "-.--": "Y",
        "--..": "Z", "-----": "0", ".----": "1", "..---": "2",
        "...--": "3", "....-": "4", ".....": "5", "-....": "6",
        "--...": "7", "---..": "8", "----.": "9",
    }

    def solve(self, value: str) -> list[SolverFinding]:
        stripped = value.strip()
        if not stripped or not re.fullmatch(r"[\s./-]+", stripped):
            return []
        words = re.split(r"\s*/\s*|\s{3,}", stripped)
        decoded_words = []
        for word in words:
            letters = []
            for token in word.split():
                if token not in self.TABLE:
                    return []
                letters.append(self.TABLE[token])
            decoded_words.append("".join(letters))
        return [SolverFinding(
            self.plugin_id, self.name, " ".join(decoded_words), 0.94,
            "Morse symbols decoded.",
        )]


class UrlDecodePlugin:
    plugin_id = "encoding.url"
    name = "URL Decoder"
    category = "web"
    description = "Percent and plus-sign URL decoding."

    def solve(self, value: str) -> list[SolverFinding]:
        decoded = unquote_plus(value)
        if decoded == value:
            return []
        return [SolverFinding(
            self.plugin_id, self.name, decoded, 0.93,
            "URL-encoded characters decoded.",
        )]


class HtmlEntityPlugin:
    plugin_id = "encoding.html_entities"
    name = "HTML Entity Decoder"
    category = "web"
    description = "HTML entity decoding."

    def solve(self, value: str) -> list[SolverFinding]:
        decoded = html.unescape(value)
        if decoded == value:
            return []
        return [SolverFinding(
            self.plugin_id, self.name, decoded, 0.91,
            "HTML entities decoded.",
        )]


class JwtDecodePlugin:
    plugin_id = "web.jwt_decode"
    name = "JWT Inspector"
    category = "web"
    description = "Decodes JWT header/payload without modifying signatures."

    def solve(self, value: str) -> list[SolverFinding]:
        match = re.search(
            r"(eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]*)",
            value,
        )
        if not match:
            return []
        parts = match.group(1).split(".")
        if len(parts) != 3:
            return []
        decoded_parts = []
        for label, part in zip(("header", "payload"), parts[:2]):
            try:
                padded = part + "=" * (-len(part) % 4)
                raw = base64.urlsafe_b64decode(padded)
                decoded_parts.append({label: json.loads(raw.decode("utf-8"))})
            except Exception:
                return []
        return [SolverFinding(
            self.plugin_id,
            self.name,
            json.dumps(decoded_parts, ensure_ascii=False, indent=2),
            0.96,
            "JWT header and payload decoded; signature unchanged.",
        )]


class UnicodeEscapePlugin:
    plugin_id = "misc.unicode_escape"
    name = "Unicode Escape Decoder"
    category = "misc"
    description = r"Decodes \uXXXX and \xNN escape sequences."

    def solve(self, value: str) -> list[SolverFinding]:
        if not re.search(r"\\[ux][0-9a-fA-F]{2,8}", value):
            return []
        try:
            decoded = codecs.decode(value, "unicode_escape")
        except Exception:
            return []
        if decoded == value or not printable(decoded):
            return []
        return [SolverFinding(
            self.plugin_id, self.name, decoded, 0.90,
            "Unicode/hex escape sequences decoded.",
        )]


class ReverseTextPlugin:
    plugin_id = "misc.reverse"
    name = "Reverse Text"
    category = "misc"
    description = "Reverses a string when a flag-like result appears."

    def solve(self, value: str) -> list[SolverFinding]:
        stripped = value.strip()
        if len(stripped) < 4:
            return []
        decoded = stripped[::-1]
        if not ("{" in decoded and "}" in decoded):
            return []
        return [SolverFinding(
            self.plugin_id, self.name, decoded, 0.88,
            "Input reversed character-by-character.",
        )]


class JsonPrettyPlugin:
    plugin_id = "misc.json_pretty"
    name = "JSON Formatter"
    category = "misc"
    description = "Parses and formats JSON clues."

    def solve(self, value: str) -> list[SolverFinding]:
        stripped = value.strip()
        if not stripped.startswith(("{", "[")):
            return []
        try:
            payload = json.loads(stripped)
        except json.JSONDecodeError:
            return []
        decoded = json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True)
        if decoded == value:
            return []
        return [SolverFinding(
            self.plugin_id, self.name, decoded, 0.84,
            "Valid JSON parsed and formatted.",
        )]


class UnixTimestampPlugin:
    plugin_id = "misc.unix_timestamp"
    name = "Unix Timestamp Converter"
    category = "misc"
    description = "Converts plausible 10/13-digit timestamps to UTC."

    def solve(self, value: str) -> list[SolverFinding]:
        findings = []
        for token in re.findall(r"\b(?:\d{10}|\d{13})\b", value):
            number = int(token)
            seconds = number / 1000 if len(token) == 13 else number
            try:
                moment = datetime.fromtimestamp(seconds, tz=timezone.utc)
            except (OverflowError, OSError, ValueError):
                continue
            if not 2000 <= moment.year <= 2100:
                continue
            findings.append(SolverFinding(
                self.plugin_id,
                self.name,
                f"{token} -> {moment.isoformat()}",
                0.82,
                "Plausible Unix timestamp converted to UTC.",
            ))
        return findings


class HashIdentifierPlugin:
    plugin_id = "misc.hash_identifier"
    name = "Hash Identifier"
    category = "misc"
    description = "Identifies common hashes by length; does not crack them."

    LENGTHS = {
        32: "MD5 or NTLM-like 128-bit hexadecimal hash",
        40: "SHA-1-like 160-bit hexadecimal hash",
        56: "SHA-224-like hexadecimal hash",
        64: "SHA-256-like hexadecimal hash",
        96: "SHA-384-like hexadecimal hash",
        128: "SHA-512-like hexadecimal hash",
    }

    def solve(self, value: str) -> list[SolverFinding]:
        stripped = value.strip()
        if not re.fullmatch(r"[0-9a-fA-F]+", stripped):
            return []
        description = self.LENGTHS.get(len(stripped))
        if not description:
            return []
        return [SolverFinding(
            self.plugin_id, self.name, description, 0.74,
            f"Identified from {len(stripped)} hexadecimal characters.",
        )]


BUILTIN_PLUGINS = [
    Base64Plugin(),
    Base32Plugin(),
    Base85Plugin(),
    HexPlugin(),
    BinaryPlugin(),
    DecimalAsciiPlugin(),
    OctalAsciiPlugin(),
    Rot13Plugin(),
    AtbashPlugin(),
    CaesarPlugin(),
    SingleByteXorPlugin(),
    VigenereKnownKeyPlugin(),
    RsaSmallNPlugin(),
    MorsePlugin(),
    UrlDecodePlugin(),
    HtmlEntityPlugin(),
    JwtDecodePlugin(),
    UnicodeEscapePlugin(),
    ReverseTextPlugin(),
    JsonPrettyPlugin(),
    UnixTimestampPlugin(),
    HashIdentifierPlugin(),
]
