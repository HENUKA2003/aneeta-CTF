from aneeta.plugins.registry import SolverRegistry

__all__ = ["SolverRegistry"]
