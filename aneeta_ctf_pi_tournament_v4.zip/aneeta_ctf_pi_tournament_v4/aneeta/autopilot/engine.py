from __future__ import annotations

import json
from typing import Any

from aneeta.ollama.client import OllamaClient, OllamaError
from aneeta.autopilot.schemas import PLAN_SCHEMA, REVIEW_SCHEMA
from aneeta.plugins.registry import SolverRegistry
from aneeta.solvers.flag_detector import find_flags


SYSTEM = """
You are the planning component of an authorized CTF learning assistant.
You may only select solver plugin IDs from the supplied allowlist.
You may not request shell commands, network attacks, credentials, exploitation,
password changes, persistence, destructive actions, or flag submission.
Your job is to classify the supplied text and choose safe decoding plugins.
Return only the JSON object required by the schema.
""".strip()


class AutopilotEngine:
    def __init__(
        self,
        client: OllamaClient,
        registry: SolverRegistry,
        max_rounds: int = 3,
    ):
        self.client = client
        self.registry = registry
        self.max_rounds = max(1, min(max_rounds, 5))

    def _allowed_ids(self) -> set[str]:
        return {item["plugin_id"] for item in self.registry.describe()}

    def _sanitize_plugins(self, requested: list[Any]) -> list[str]:
        allowed = self._allowed_ids()
        clean: list[str] = []
        for value in requested:
            item = str(value)
            if item in allowed and item not in clean:
                clean.append(item)
        return clean

    def _fallback_plan(self) -> dict:
        return {
            "category": "misc",
            "selected_plugins": sorted(self._allowed_ids()),
            "max_depth": 5,
            "summary": (
                "Ollama plan unavailable; using the deterministic "
                "allowlisted solver library."
            ),
            "confidence": 0.35,
            "source": "fallback",
        }

    def _plan(self, challenge_text: str, flag_format: str) -> dict:
        catalog = self.registry.describe()
        user = json.dumps(
            {
                "challenge_text": challenge_text[:16000],
                "flag_format": flag_format,
                "allowed_plugins": catalog,
                "instruction": (
                    "Choose only useful plugin IDs. For layered encoding, "
                    "use max_depth between 3 and 6."
                ),
            },
            ensure_ascii=False,
        )

        try:
            plan = self.client.chat_structured(
                system=SYSTEM,
                user=user,
                schema=PLAN_SCHEMA,
            )
            plan["selected_plugins"] = self._sanitize_plugins(
                plan.get("selected_plugins", [])
            )
            plan["max_depth"] = max(1, min(int(plan.get("max_depth", 5)), 6))
            if not plan["selected_plugins"]:
                plan["selected_plugins"] = sorted(self._allowed_ids())
            plan["source"] = "ollama"
            return plan
        except (OllamaError, ValueError, TypeError):
            return self._fallback_plan()

    def _review(
        self,
        challenge_text: str,
        flag_format: str,
        findings: list[dict],
        flags: list[str],
    ) -> dict:
        user = json.dumps(
            {
                "challenge_text": challenge_text[:8000],
                "flag_format": flag_format,
                "findings": findings[-30:],
                "flags": flags,
                "allowed_plugin_ids": sorted(self._allowed_ids()),
                "instruction": (
                    "Stop when a plausible flag is present. Otherwise choose "
                    "additional safe plugins from the allowlist."
                ),
            },
            ensure_ascii=False,
        )

        try:
            review = self.client.chat_structured(
                system=SYSTEM,
                user=user,
                schema=REVIEW_SCHEMA,
            )
            review["selected_plugins"] = self._sanitize_plugins(
                review.get("selected_plugins", [])
            )
            review["source"] = "ollama"
            return review
        except (OllamaError, ValueError, TypeError):
            return {
                "stop": bool(flags),
                "selected_plugins": [],
                "summary": "Deterministic review fallback.",
                "confidence": 0.4,
                "source": "fallback",
            }

    def run(self, challenge_text: str, flag_format: str = "") -> dict:
        plan = self._plan(challenge_text, flag_format)
        active_plugins = list(plan["selected_plugins"])
        max_depth = int(plan["max_depth"])

        all_findings: list[dict] = []
        searchable: list[str] = [challenge_text]
        rounds: list[dict] = []
        flags: list[str] = []

        for round_index in range(1, self.max_rounds + 1):
            findings = self.registry.solve_recursive(
                challenge_text,
                max_depth=max_depth,
                max_nodes=120,
                plugin_ids=active_plugins,
            )

            known = {
                (item["plugin_id"], item["output"])
                for item in all_findings
            }
            new_findings = [
                item for item in findings
                if (item["plugin_id"], item["output"]) not in known
            ]
            all_findings.extend(new_findings)
            searchable.extend(str(item["output"]) for item in new_findings)

            flags = find_flags(
                "\n".join(searchable),
                custom_format=flag_format,
            )

            review = self._review(
                challenge_text,
                flag_format,
                all_findings,
                flags,
            )
            rounds.append({
                "round": round_index,
                "plugins": active_plugins,
                "new_findings": len(new_findings),
                "flags": flags,
                "review": review,
            })

            if flags or bool(review.get("stop")):
                break

            requested = review.get("selected_plugins", [])
            if not requested:
                remaining = sorted(self._allowed_ids() - set(active_plugins))
                requested = remaining

            combined = list(dict.fromkeys([*active_plugins, *requested]))
            if combined == active_plugins:
                break
            active_plugins = combined

        all_findings.sort(
            key=lambda item: (
                -float(item["confidence"]),
                int(item["depth"]),
            )
        )

        return {
            "plan": plan,
            "rounds": rounds,
            "findings": all_findings,
            "flags": flags,
            "searchable_text": searchable,
            "ollama_status": self.client.status(),
        }
