PLAN_SCHEMA = {
    "type": "object",
    "properties": {
        "category": {
            "type": "string",
            "enum": ["encoding", "crypto", "forensics", "web", "network", "misc"]
        },
        "selected_plugins": {
            "type": "array",
            "items": {"type": "string"},
            "maxItems": 8
        },
        "max_depth": {
            "type": "integer",
            "minimum": 1,
            "maximum": 6
        },
        "summary": {
            "type": "string",
            "maxLength": 600
        },
        "confidence": {
            "type": "number",
            "minimum": 0,
            "maximum": 1
        }
    },
    "required": [
        "category",
        "selected_plugins",
        "max_depth",
        "summary",
        "confidence"
    ],
    "additionalProperties": False
}

REVIEW_SCHEMA = {
    "type": "object",
    "properties": {
        "stop": {"type": "boolean"},
        "selected_plugins": {
            "type": "array",
            "items": {"type": "string"},
            "maxItems": 8
        },
        "summary": {
            "type": "string",
            "maxLength": 600
        },
        "confidence": {
            "type": "number",
            "minimum": 0,
            "maximum": 1
        }
    },
    "required": ["stop", "selected_plugins", "summary", "confidence"],
    "additionalProperties": False
}
