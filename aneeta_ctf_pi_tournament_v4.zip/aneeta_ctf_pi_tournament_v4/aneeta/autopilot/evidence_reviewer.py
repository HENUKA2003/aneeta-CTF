from __future__ import annotations

import json

from aneeta.ollama.client import OllamaClient, OllamaError


REVIEW_SCHEMA = {
    "type": "object",
    "properties": {
        "category": {
            "type": "string",
            "enum": ["crypto", "web", "forensics", "misc"],
        },
        "summary": {"type": "string", "maxLength": 1000},
        "observations": {
            "type": "array",
            "items": {"type": "string", "maxLength": 400},
            "maxItems": 8,
        },
        "next_safe_checks": {
            "type": "array",
            "items": {"type": "string", "maxLength": 400},
            "maxItems": 8,
        },
        "confidence": {
            "type": "number",
            "minimum": 0,
            "maximum": 1,
        },
    },
    "required": [
        "category",
        "summary",
        "observations",
        "next_safe_checks",
        "confidence",
    ],
    "additionalProperties": False,
}


SYSTEM = """
You review evidence from an authorized CTF assistant.
Use only supplied evidence and never invent a flag.
Do not request credentials, password attacks, persistence, destructive actions,
scope expansion, arbitrary shell commands, or attacks on unrelated systems.
For web evidence, suggest only non-destructive same-target checks.
For forensics evidence, suggest read-only file or packet inspection.
Return only the JSON required by the schema.
""".strip()


class EvidenceReviewer:
    def __init__(self, client: OllamaClient):
        self.client = client

    def review(
        self,
        category: str,
        challenge_context: str,
        flags: list[str],
        reports: list[dict],
        steps: list[dict],
    ) -> dict:
        status = self.client.status()
        if not status.get("online") or not status.get("model_available"):
            return {
                "category": category,
                "summary": "Ollama offline හෝ model එක install කරලා නැහැ.",
                "observations": [],
                "next_safe_checks": [],
                "confidence": 0.0,
                "source": "offline",
            }

        user = json.dumps(
            {
                "category": category,
                "challenge_context": challenge_context[:10000],
                "flag_candidates": flags,
                "reports": reports[-5:],
                "steps": steps[-25:],
            },
            ensure_ascii=False,
        )

        try:
            result = self.client.chat_structured(
                system=SYSTEM,
                user=user,
                schema=REVIEW_SCHEMA,
                temperature=0.1,
            )
            result["source"] = "ollama"
            return result
        except (OllamaError, ValueError, TypeError) as exc:
            return {
                "category": category,
                "summary": f"Ollama review failed: {exc}",
                "observations": [],
                "next_safe_checks": [],
                "confidence": 0.0,
                "source": "fallback",
            }


def format_review(review: dict) -> str:
    lines = [
        f"Category: {review.get('category', '')}",
        f"Confidence: {review.get('confidence', 0)}",
        f"Source: {review.get('source', '')}",
        "",
        str(review.get("summary", "")),
    ]

    observations = review.get("observations", [])
    if observations:
        lines.extend(["", "Observations:"])
        lines.extend(f"- {item}" for item in observations)

    checks = review.get("next_safe_checks", [])
    if checks:
        lines.extend(["", "Next safe checks:"])
        lines.extend(f"- {item}" for item in checks)

    return "\n".join(lines)
