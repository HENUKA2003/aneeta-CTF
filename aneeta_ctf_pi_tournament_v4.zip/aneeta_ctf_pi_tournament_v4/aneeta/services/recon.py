from __future__ import annotations

import shutil
import subprocess
import xml.etree.ElementTree as ET

from aneeta.models import Report, Step


def parse_nmap_xml(xml_text: str) -> list[dict]:
    services: list[dict] = []
    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError:
        return services

    for port in root.findall(".//port"):
        state = port.find("state")
        if state is None or state.attrib.get("state") != "open":
            continue

        service = port.find("service")
        services.append({
            "protocol": port.attrib.get("protocol", ""),
            "port": int(port.attrib.get("portid", "0")),
            "service": service.attrib.get("name", "") if service is not None else "",
            "product": service.attrib.get("product", "") if service is not None else "",
            "version": service.attrib.get("version", "") if service is not None else "",
            "extra": service.attrib.get("extrainfo", "") if service is not None else "",
        })
    return services


def run_nmap_recon(target: str) -> dict:
    if not shutil.which("nmap"):
        raise ValueError("`nmap` install කරලා නැහැ.")

    # Deliberately limited, non-stealthy discovery for one authorized host.
    command = [
        "nmap",
        "-sT",
        "-sV",
        "--version-light",
        "--top-ports",
        "100",
        "-T3",
        "-oX",
        "-",
        target,
    ]

    try:
        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=180,
            check=False,
        )
    except subprocess.TimeoutExpired as exc:
        raise ValueError("Recon scan එක timeout වුණා.") from exc

    services = parse_nmap_xml(result.stdout)
    lines = []
    for item in services:
        version = " ".join(
            value for value in [
                item["product"],
                item["version"],
                item["extra"],
            ] if value
        )
        lines.append(
            f"{item['port']}/{item['protocol']} "
            f"{item['service'] or 'unknown'} {version}".strip()
        )

    output = "\n".join(lines) if lines else "No open ports found in top 100 ports."
    if result.stderr.strip():
        output += f"\n\nNmap notes:\n{result.stderr.strip()[:4000]}"

    return {
        "steps": [
            Step(
                "Authorized host recon",
                f"Target: {target}\nCommand profile: TCP connect, "
                f"service detection, top 100 ports.\n\n{output}",
            ).to_dict()
        ],
        "report": Report(
            "recon",
            "Authorized target recon",
            {
                "target": target,
                "services": services,
                "exit_code": result.returncode,
            },
        ).to_dict(),
        "searchable_text": [
            target,
            output,
            result.stdout[:20000],
            result.stderr[:4000],
        ],
    }
