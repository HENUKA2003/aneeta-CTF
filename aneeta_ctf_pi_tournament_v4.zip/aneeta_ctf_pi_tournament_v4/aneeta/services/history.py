from __future__ import annotations

from datetime import datetime, timezone
import json
from pathlib import Path


class HistoryStore:
    def __init__(self, path: Path):
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def append(self, item: dict) -> None:
        payload = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            **item,
        }
        with self.path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(payload, ensure_ascii=False) + "\n")

    def latest(self, limit: int = 10) -> list[dict]:
        if not self.path.exists():
            return []

        lines = self.path.read_text(encoding="utf-8", errors="replace").splitlines()
        items: list[dict] = []
        for line in lines[-limit:]:
            try:
                items.append(json.loads(line))
            except json.JSONDecodeError:
                continue
        return list(reversed(items))
