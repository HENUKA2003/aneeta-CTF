from __future__ import annotations

from dataclasses import dataclass
import json
import os
from typing import Any

import requests


SYSTEM_RULES = """
You are an authorized CTF analysis advisor. Summarize evidence already collected.
Do not produce exploit payloads, credential attacks, persistence steps, malware,
destructive commands, or instructions for attacking systems outside the stated CTF.
Do not claim a flag is correct unless it appears in the supplied evidence.
Provide: category guess, important observations, safe next checks, and uncertainty.
Keep the answer concise.
""".strip()


@dataclass
class AIAdvisor:
    backend: str
    base_url: str
    model: str
    api_key: str = ""

    @property
    def enabled(self) -> bool:
        return self.backend in {"ollama", "openai_compatible"}

    @classmethod
    def from_environment(cls) -> "AIAdvisor":
        backend = os.getenv("AI_BACKEND", "none").strip().lower()
        if backend == "ollama":
            return cls(
                backend="ollama",
                base_url=os.getenv(
                    "OLLAMA_URL",
                    "http://127.0.0.1:11434",
                ).rstrip("/"),
                model=os.getenv("OLLAMA_MODEL", "qwen2.5:1.5b"),
            )

        if backend == "openai_compatible":
            return cls(
                backend="openai_compatible",
                base_url=os.getenv("AI_BASE_URL", "").rstrip("/"),
                model=os.getenv("AI_MODEL", ""),
                api_key=os.getenv("AI_API_KEY", ""),
            )

        return cls("none", "", "")

    def summarize(self, action: str, text: str, steps: list[dict]) -> str:
        if not self.enabled:
            return ""

        evidence = {
            "action": action,
            "steps": steps[-20:],
            "evidence": text[-30000:],
        }
        prompt = (
            SYSTEM_RULES
            + "\n\nEvidence JSON:\n"
            + json.dumps(evidence, ensure_ascii=False)
        )

        try:
            if self.backend == "ollama":
                return self._ollama(prompt)
            return self._openai_compatible(prompt)
        except Exception as exc:
            return f"AI advisor error: {exc}"

    def _ollama(self, prompt: str) -> str:
        response = requests.post(
            f"{self.base_url}/api/generate",
            json={
                "model": self.model,
                "prompt": prompt,
                "stream": False,
            },
            timeout=90,
        )
        response.raise_for_status()
        return str(response.json().get("response", "")).strip()

    def _openai_compatible(self, prompt: str) -> str:
        if not self.base_url or not self.model:
            raise ValueError("AI_BASE_URL සහ AI_MODEL configure කරන්න.")

        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        response = requests.post(
            f"{self.base_url}/chat/completions",
            headers=headers,
            json={
                "model": self.model,
                "messages": [
                    {"role": "system", "content": SYSTEM_RULES},
                    {"role": "user", "content": prompt},
                ],
                "temperature": 0.2,
            },
            timeout=90,
        )
        response.raise_for_status()
        data: dict[str, Any] = response.json()
        return str(data["choices"][0]["message"]["content"]).strip()
