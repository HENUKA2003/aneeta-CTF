from __future__ import annotations

from pathlib import Path

from aneeta.analyzers.file_analyzer import analyze_uploaded_file
from aneeta.importers.browser_capture import import_latest_capture
from aneeta.importers.url_importer import import_url
from aneeta.security.scope_guard import validate_authorized_target
from aneeta.services.recon import run_nmap_recon
from aneeta.solvers.encoding_solver import analyze_encodings
from aneeta.solvers.flag_detector import find_flags


def _base_result() -> dict:
    return {
        "steps": [],
        "reports": [],
        "flags": [],
        "searchable_text": [],
    }


def analyze_text(text: str, flag_format: str = "") -> dict:
    result = _base_result()
    steps, outputs = analyze_encodings(text)
    result["steps"].extend(steps)
    result["searchable_text"].extend([text, *outputs])
    result["flags"] = find_flags(
        "\n".join(result["searchable_text"]),
        custom_format=flag_format,
    )
    result["reports"].append({
        "kind": "text",
        "title": "Challenge text",
        "data": {"characters": len(text)},
    })
    return result


def analyze_url(
    url: str,
    flag_format: str = "",
    allow_private: bool = False,
) -> dict:
    result = _base_result()
    imported = import_url(url, allow_private=allow_private)
    result["steps"].extend(imported["steps"])
    result["reports"].append(imported["report"])
    result["searchable_text"].extend(imported["searchable_text"])

    detected = flag_format or imported.get("detected_flag_format", "")
    result["flags"] = find_flags(
        "\n".join(result["searchable_text"]),
        custom_format=detected,
    )
    return result


def analyze_browser_capture(flag_format: str = "") -> dict:
    result = _base_result()
    imported = import_latest_capture()
    result["steps"].extend(imported["steps"])
    result["reports"].append(imported["report"])
    result["searchable_text"].extend(imported["searchable_text"])

    detected = flag_format or imported.get("detected_flag_format", "")
    result["flags"] = find_flags(
        "\n".join(result["searchable_text"]),
        custom_format=detected,
    )
    return result


def analyze_file(path: Path, original_name: str, flag_format: str = "") -> dict:
    result = _base_result()
    analyzed = analyze_uploaded_file(path, original_name)
    result["steps"].extend(analyzed["steps"])
    result["reports"].append(analyzed["report"])
    result["searchable_text"].extend(analyzed["searchable_text"])
    result["flags"] = find_flags(
        "\n".join(result["searchable_text"]),
        custom_format=flag_format,
    )
    return result


def run_scoped_recon(
    target: str,
    flag_format: str = "",
    authorized: bool = False,
) -> dict:
    result = _base_result()
    validated = validate_authorized_target(target, authorized=authorized)
    recon = run_nmap_recon(validated)

    result["steps"].extend(recon["steps"])
    result["reports"].append(recon["report"])
    result["searchable_text"].extend(recon["searchable_text"])
    result["flags"] = find_flags(
        "\n".join(result["searchable_text"]),
        custom_format=flag_format,
    )
    return result
