from __future__ import annotations

from aneeta.plugins.registry import SolverRegistry
from aneeta.solvers.flag_detector import find_flags


CATEGORY_MAP = {
    "crypto": {"crypto", "encoding"},
    "misc": {"misc", "encoding", "web"},
}


def analyze_category_text(
    text: str,
    category: str,
    flag_format: str,
    registry: SolverRegistry,
) -> dict:
    selected_categories = CATEGORY_MAP.get(category)
    if not selected_categories:
        raise ValueError("Category එක crypto හෝ misc විය යුතුයි.")

    plugin_ids = [
        item["plugin_id"]
        for item in registry.describe()
        if item["category"] in selected_categories
    ]

    findings = registry.solve_recursive(
        text,
        max_depth=6,
        max_nodes=180,
        plugin_ids=plugin_ids,
    )

    searchable = [text, *(str(item["output"]) for item in findings)]
    flags = find_flags("\n".join(searchable), custom_format=flag_format)

    steps = []
    for item in findings[:100]:
        steps.append({
            "title": (
                f"{item['plugin_name']} "
                f"(depth {item['depth']}, confidence {item['confidence']:.2f})"
            ),
            "output": (
                f"{item['explanation']}\n"
                f"Chain: {' -> '.join(item['chain'])}\n\n"
                f"{item['output']}"
            ),
            "severity": "info",
        })

    return {
        "flags": flags,
        "steps": steps,
        "reports": [{
            "kind": category,
            "title": f"{category.title()} Category Lab",
            "data": {
                "plugins_considered": plugin_ids,
                "findings": len(findings),
                "flag_candidates": len(flags),
            },
        }],
        "searchable_text": searchable,
        "findings": findings,
    }
