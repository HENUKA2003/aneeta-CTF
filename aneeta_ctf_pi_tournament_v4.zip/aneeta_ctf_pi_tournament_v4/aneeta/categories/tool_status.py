from __future__ import annotations

import shutil


TOOLS = {
    "file": "Core file identification",
    "strings": "Printable string extraction",
    "exiftool": "Metadata and EXIF",
    "binwalk": "Embedded signature scan",
    "tshark": "PCAP packet analysis",
    "capinfos": "PCAP summary",
    "zbarimg": "QR/barcode decoding",
    "pdfinfo": "PDF metadata",
    "pdftotext": "PDF text extraction",
    "steghide": "Steghide info check",
    "7z": "7-Zip archive listing",
    "radare2": "Basic binary inspection",
}


def tool_status() -> list[dict]:
    return [
        {
            "command": command,
            "available": bool(shutil.which(command)),
            "purpose": purpose,
        }
        for command, purpose in TOOLS.items()
    ]
