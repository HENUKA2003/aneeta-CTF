from __future__ import annotations

from pathlib import Path
import shutil
import subprocess

from aneeta.analyzers.file_analyzer import analyze_uploaded_file
from aneeta.solvers.flag_detector import find_flags


def run_readonly(
    command: list[str],
    timeout: int = 30,
    max_chars: int = 12000,
) -> dict:
    if not shutil.which(command[0]):
        return {
            "command": command[0],
            "available": False,
            "output": "",
            "error": "Tool not installed.",
        }

    try:
        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
        combined = result.stdout
        if result.stderr.strip():
            combined += "\n[stderr]\n" + result.stderr
        return {
            "command": " ".join(command),
            "available": True,
            "exit_code": result.returncode,
            "output": combined[:max_chars],
            "error": "",
        }
    except subprocess.TimeoutExpired:
        return {
            "command": " ".join(command),
            "available": True,
            "output": "",
            "error": "Timed out.",
        }
    except Exception as exc:
        return {
            "command": " ".join(command),
            "available": True,
            "output": "",
            "error": str(exc),
        }


def is_pcap(description: str, suffix: str) -> bool:
    lowered = description.lower()
    return (
        suffix in {".pcap", ".pcapng", ".cap"}
        or "pcap" in lowered
        or "capture file" in lowered
    )


def analyze_forensics_file(
    path: Path,
    original_name: str,
    flag_format: str,
) -> dict:
    base = analyze_uploaded_file(path, original_name)
    report_data = base["report"]["data"]
    description = str(report_data.get("description", ""))
    suffix = path.suffix.lower()

    steps = list(base["steps"])
    searchable = list(base["searchable_text"])
    tools_run = []

    commands = [
        ["exiftool", str(path)],
        ["binwalk", str(path)],
        ["zbarimg", "--quiet", str(path)],
    ]

    if suffix == ".pdf" or "pdf" in description.lower():
        commands.extend([
            ["pdfinfo", str(path)],
            ["pdftotext", str(path), "-"],
        ])

    if suffix in {".jpg", ".jpeg", ".bmp", ".wav", ".au"}:
        commands.append(["steghide", "info", str(path), "-p", ""])

    if is_pcap(description, suffix):
        commands.extend([
            ["capinfos", str(path)],
            ["tshark", "-r", str(path), "-q", "-z", "io,phs"],
            [
                "tshark", "-r", str(path), "-c", "250",
                "-T", "fields",
                "-e", "frame.number",
                "-e", "ip.src",
                "-e", "ip.dst",
                "-e", "_ws.col.Protocol",
                "-e", "_ws.col.Info",
            ],
            [
                "tshark", "-r", str(path),
                "-Y", "dns.qry.name",
                "-T", "fields",
                "-e", "dns.qry.name",
            ],
            [
                "tshark", "-r", str(path),
                "-Y", "http.request",
                "-T", "fields",
                "-e", "http.host",
                "-e", "http.request.uri",
                "-e", "http.user_agent",
            ],
        ])

    for command in commands:
        result = run_readonly(command)
        tools_run.append(result)
        if result.get("output"):
            searchable.append(str(result["output"]))
            steps.append({
                "title": f"Tool: {command[0]}",
                "output": str(result["output"]),
                "severity": "info",
            })

    flags = find_flags("\n".join(searchable), custom_format=flag_format)

    return {
        "flags": flags,
        "steps": steps,
        "reports": [
            base["report"],
            {
                "kind": "forensics",
                "title": "Forensics Tool Report",
                "data": {
                    "tools": [
                        {
                            "command": item.get("command"),
                            "available": item.get("available"),
                            "exit_code": item.get("exit_code"),
                            "error": item.get("error"),
                        }
                        for item in tools_run
                    ],
                    "pcap_detected": is_pcap(description, suffix),
                    "note": (
                        "Automatic external commands are read-only inspection."
                    ),
                },
            },
        ],
        "searchable_text": searchable,
        "tool_results": tools_run,
    }
