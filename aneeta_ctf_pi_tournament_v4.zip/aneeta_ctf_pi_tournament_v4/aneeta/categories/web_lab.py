from __future__ import annotations

import json
import re
from urllib.parse import urljoin, urlparse

import requests
from bs4 import BeautifulSoup, Comment

from aneeta.importers.url_importer import validate_url
from aneeta.plugins.registry import SolverRegistry
from aneeta.solvers.flag_detector import find_flags


MAX_PAGE_BYTES = 2 * 1024 * 1024
MAX_AUX_BYTES = 256 * 1024
TIMEOUT = 15

SECURITY_HEADERS = [
    "Content-Security-Policy",
    "X-Content-Type-Options",
    "Referrer-Policy",
    "Permissions-Policy",
]


def read_limited(response: requests.Response, limit: int) -> bytes:
    raw = response.raw.read(limit + 1, decode_content=True)
    if len(raw) > limit:
        raise ValueError("Response size limit එකට වඩා විශාලයි.")
    return raw


def same_origin(base_url: str, candidate: str) -> bool:
    base = urlparse(base_url)
    other = urlparse(candidate)
    return (
        base.scheme == other.scheme
        and base.hostname == other.hostname
        and (base.port or (443 if base.scheme == "https" else 80))
        == (other.port or (443 if other.scheme == "https" else 80))
    )


def extract_js_endpoints(text: str) -> list[str]:
    patterns = [
        r"""["']((?:/|\./)[A-Za-z0-9_./?=&%-]{2,200})["']""",
        r"""fetch\(\s*["']([^"']{1,200})["']""",
        r"""axios\.(?:get|post|put|delete)\(\s*["']([^"']{1,200})["']""",
    ]
    found: list[str] = []
    for pattern in patterns:
        for match in re.findall(pattern, text):
            value = str(match).strip()
            if value and value not in found:
                found.append(value)
    return found[:200]


def fetch_auxiliary(
    session: requests.Session,
    base_url: str,
    path: str,
) -> dict:
    url = urljoin(base_url, path)
    if not same_origin(base_url, url):
        return {"url": url, "status": "blocked", "body": ""}

    try:
        response = session.get(
            url,
            timeout=TIMEOUT,
            allow_redirects=False,
            stream=True,
        )
        body = read_limited(response, MAX_AUX_BYTES).decode(
            response.encoding or "utf-8",
            errors="replace",
        )
        return {
            "url": url,
            "status": response.status_code,
            "content_type": response.headers.get("Content-Type", ""),
            "body": body,
        }
    except Exception as exc:
        return {
            "url": url,
            "status": "error",
            "body": "",
            "error": str(exc),
        }


def analyze_web_challenge(
    url: str,
    flag_format: str,
    allow_private: bool,
    registry: SolverRegistry,
) -> dict:
    validate_url(url, allow_private)

    session = requests.Session()
    session.headers["User-Agent"] = "Aneeta-CTF-Web-Lab/3.0 authorized"

    response = session.get(
        url,
        timeout=TIMEOUT,
        allow_redirects=True,
        stream=True,
    )
    response.raise_for_status()

    validate_url(response.url, allow_private)
    content_type = response.headers.get("Content-Type", "")
    if "text/html" not in content_type.lower():
        raise ValueError(
            f"Web lab එකට HTML page එකක් ඕනේ. "
            f"Content-Type: {content_type or 'Unknown'}"
        )

    raw = read_limited(response, MAX_PAGE_BYTES)
    html = raw.decode(response.encoding or "utf-8", errors="replace")
    soup = BeautifulSoup(html, "html.parser")
    title = soup.title.get_text(" ", strip=True) if soup.title else "Untitled"

    comments = [
        str(item).strip()
        for item in soup.find_all(
            string=lambda value: isinstance(value, Comment)
        )
        if str(item).strip()
    ][:200]

    forms = []
    for form in soup.find_all("form")[:50]:
        fields = []
        for item in form.find_all(["input", "textarea", "select"])[:100]:
            fields.append({
                "tag": item.name,
                "name": item.get("name", ""),
                "type": item.get("type", ""),
            })
        forms.append({
            "method": str(form.get("method", "GET")).upper(),
            "action": urljoin(response.url, form.get("action", "")),
            "fields": fields,
        })

    scripts: list[str] = []
    inline_js: list[str] = []
    for script in soup.find_all("script")[:200]:
        src = script.get("src")
        if src:
            absolute = urljoin(response.url, src)
            if same_origin(response.url, absolute) and absolute not in scripts:
                scripts.append(absolute)
        else:
            content = script.get_text("\n", strip=True)
            if content:
                inline_js.append(content[:100000])

    js_endpoints = extract_js_endpoints("\n".join(inline_js))

    cookie_report = []
    for cookie in response.cookies:
        cookie_report.append({
            "name": cookie.name,
            "secure": bool(cookie.secure),
            "domain": cookie.domain,
            "path": cookie.path,
        })

    headers = dict(response.headers.items())
    missing_security_headers = [
        name for name in SECURITY_HEADERS
        if name not in response.headers
    ]

    auxiliaries = [
        fetch_auxiliary(session, response.url, "/robots.txt"),
        fetch_auxiliary(session, response.url, "/sitemap.xml"),
        fetch_auxiliary(session, response.url, "/.well-known/security.txt"),
    ]

    visible_soup = BeautifulSoup(html, "html.parser")
    for tag in visible_soup(["script", "style", "noscript", "svg"]):
        tag.decompose()
    visible_text = visible_soup.get_text("\n", strip=True)

    web_plugin_ids = [
        item["plugin_id"]
        for item in registry.describe()
        if item["category"] in {"web", "encoding", "misc"}
    ]
    plugin_input = "\n".join([
        visible_text,
        *comments,
        *inline_js,
        *(str(aux.get("body", "")) for aux in auxiliaries),
    ])
    plugin_findings = registry.solve_recursive(
        plugin_input,
        max_depth=4,
        max_nodes=120,
        plugin_ids=web_plugin_ids,
    )

    searchable = [
        title,
        response.url,
        visible_text,
        html,
        json.dumps(headers),
        json.dumps(forms),
        *comments,
        *inline_js,
        *scripts,
        *js_endpoints,
        *(str(aux.get("body", "")) for aux in auxiliaries),
        *(str(item["output"]) for item in plugin_findings),
    ]
    flags = find_flags("\n".join(searchable), custom_format=flag_format)

    steps = [
        {
            "title": "HTTP response",
            "output": (
                f"Title: {title}\n"
                f"Final URL: {response.url}\n"
                f"Status: {response.status_code}\n"
                f"Content-Type: {content_type or 'Unknown'}\n"
                f"Forms: {len(forms)}\n"
                f"Same-origin scripts: {len(scripts)}\n"
                f"Inline JS blocks: {len(inline_js)}"
            ),
            "severity": "info",
        },
        {
            "title": "Response headers",
            "output": json.dumps(headers, ensure_ascii=False, indent=2)[:12000],
            "severity": "info",
        },
        {
            "title": "Forms and field names",
            "output": json.dumps(forms, ensure_ascii=False, indent=2)[:12000],
            "severity": "info",
        },
    ]

    if comments:
        steps.append({
            "title": "HTML comments",
            "output": "\n\n".join(comments)[:12000],
            "severity": "info",
        })
    if js_endpoints:
        steps.append({
            "title": "JavaScript endpoint clues",
            "output": "\n".join(js_endpoints),
            "severity": "info",
        })

    steps.append({
        "title": "Public auxiliary files",
        "output": json.dumps(
            [
                {
                    "url": item.get("url"),
                    "status": item.get("status"),
                    "content_type": item.get("content_type", ""),
                    "preview": str(item.get("body", ""))[:3000],
                    "error": item.get("error", ""),
                }
                for item in auxiliaries
            ],
            ensure_ascii=False,
            indent=2,
        )[:12000],
        "severity": "info",
    })

    for item in plugin_findings[:60]:
        steps.append({
            "title": (
                f"{item['plugin_name']} "
                f"(depth {item['depth']}, confidence {item['confidence']:.2f})"
            ),
            "output": (
                f"{item['explanation']}\n"
                f"Chain: {' -> '.join(item['chain'])}\n\n"
                f"{item['output']}"
            ),
            "severity": "info",
        })

    return {
        "flags": flags,
        "steps": steps,
        "reports": [{
            "kind": "web",
            "title": "Web CTF Inspector",
            "data": {
                "title": title,
                "final_url": response.url,
                "status": response.status_code,
                "forms": forms,
                "same_origin_scripts": scripts,
                "javascript_endpoint_clues": js_endpoints,
                "cookies": cookie_report,
                "missing_security_headers": missing_security_headers,
                "auxiliary_files": [
                    {
                        "url": item.get("url"),
                        "status": item.get("status"),
                    }
                    for item in auxiliaries
                ],
                "note": (
                    "Missing headers are observations only, "
                    "not proof of an exploitable issue."
                ),
            },
        }],
        "searchable_text": searchable,
        "findings": plugin_findings,
    }
