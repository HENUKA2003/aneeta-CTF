from __future__ import annotations

import json
from pathlib import Path
import re

from aneeta.models import Report, Step
from aneeta.solvers.encoding_solver import analyze_encodings

BASE_DIR = Path(__file__).resolve().parents[2]
LATEST = BASE_DIR / "runtime" / "captures" / "latest.json"
MAX_BYTES = 5 * 1024 * 1024


def detect_flag_format(text: str) -> str:
    patterns = [
        r"\b([A-Za-z0-9_]{2,30})\{\.\.\.\}",
        r"flag\s*format\s*[:\-]\s*([A-Za-z0-9_]{2,30})\{",
    ]
    for pattern in patterns:
        match = re.search(pattern, text, flags=re.IGNORECASE)
        if match:
            return f"{match.group(1)}{{...}}"
    return ""


def import_latest_capture() -> dict:
    if not LATEST.exists():
        raise ValueError(
            "Browser capture එකක් නැහැ. `python browser_capture.py` run කරන්න."
        )
    if LATEST.stat().st_size > MAX_BYTES:
        raise ValueError("Browser capture එක 5 MB limit එකට වඩා විශාලයි.")

    payload = json.loads(LATEST.read_text(encoding="utf-8"))
    title = str(payload.get("title", "Untitled"))
    url = str(payload.get("url", ""))
    captured_at = str(payload.get("captured_at", "Unknown"))
    text = str(payload.get("visible_text", ""))
    html = str(payload.get("html", ""))
    comments = [
        str(item) for item in payload.get("comments", [])
        if isinstance(item, str)
    ]
    attachments = [
        str(item) for item in payload.get("attachment_links", [])
        if isinstance(item, str)
    ]

    steps = [
        Step(
            "Browser capture",
            f"Title: {title}\nURL: {url}\nCaptured: {captured_at}\n"
            f"Attachment links: {len(attachments)}",
        ).to_dict(),
        Step("Visible page text", text[:12000] or "No visible text.").to_dict(),
    ]
    if comments:
        steps.append(
            Step("HTML comments", "\n\n".join(comments)[:12000]).to_dict()
        )
    if attachments:
        steps.append(
            Step("Attachment links", "\n".join(attachments[:100])).to_dict()
        )

    decoded_steps, decoded_outputs = analyze_encodings(text)
    steps.extend(decoded_steps)

    searchable = [title, url, text, html, *comments, *attachments, *decoded_outputs]
    detected = detect_flag_format("\n".join([text, *comments]))

    return {
        "steps": steps,
        "report": Report(
            "browser",
            "Saved browser challenge",
            {
                "title": title,
                "url": url,
                "captured_at": captured_at,
                "attachment_links": attachments,
                "detected_flag_format": detected,
            },
        ).to_dict(),
        "searchable_text": searchable,
        "detected_flag_format": detected,
    }
