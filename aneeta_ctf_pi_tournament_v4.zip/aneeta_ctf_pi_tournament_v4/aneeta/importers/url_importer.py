from __future__ import annotations

import ipaddress
import re
import socket
from urllib.parse import urljoin, urlparse

import requests
from bs4 import BeautifulSoup, Comment

from aneeta.models import Report, Step
from aneeta.solvers.encoding_solver import analyze_encodings

MAX_PAGE = 2 * 1024 * 1024
TIMEOUT = 15

ATTACHMENT_EXTENSIONS = (
    ".zip", ".7z", ".rar", ".tar", ".gz", ".tgz",
    ".txt", ".log", ".csv", ".json", ".xml",
    ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp",
    ".pdf", ".pcap", ".pcapng", ".bin", ".elf",
    ".py", ".js", ".sh", ".c", ".cpp", ".java",
)


def validate_url(url: str, allow_private: bool) -> None:
    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https"}:
        raise ValueError("HTTP/HTTPS URL එකක් පමණක් දෙන්න.")
    if not parsed.hostname:
        raise ValueError("Valid hostname එකක් නැහැ.")

    try:
        addresses = {
            item[4][0]
            for item in socket.getaddrinfo(
                parsed.hostname,
                parsed.port or (443 if parsed.scheme == "https" else 80),
            )
        }
    except socket.gaierror as exc:
        raise ValueError(f"Hostname resolve කරන්න බැහැ: {exc}") from exc

    for address in addresses:
        ip = ipaddress.ip_address(address)
        restricted = (
            ip.is_loopback
            or ip.is_link_local
            or ip.is_multicast
            or ip.is_reserved
            or ip.is_unspecified
            or ip.is_private
        )
        if restricted and not allow_private:
            raise ValueError(
                "Private/local URL එකක් detect වුණා. "
                "Authorized CTF target නම් checkbox එක tick කරන්න."
            )


def detect_flag_format(text: str) -> str:
    patterns = [
        r"\b([A-Za-z0-9_]{2,30})\{\.\.\.\}",
        r"flag\s*format\s*[:\-]\s*([A-Za-z0-9_]{2,30})\{",
    ]
    for pattern in patterns:
        match = re.search(pattern, text, flags=re.IGNORECASE)
        if match:
            return f"{match.group(1)}{{...}}"
    return ""


def clean_text(html: str) -> str:
    soup = BeautifulSoup(html, "html.parser")
    for tag in soup(["script", "style", "noscript", "svg"]):
        tag.decompose()
    lines = [
        re.sub(r"\s+", " ", line).strip()
        for line in soup.get_text("\n").splitlines()
    ]
    return "\n".join(line for line in lines if line)


def import_url(url: str, allow_private: bool = False) -> dict:
    validate_url(url, allow_private)

    response = requests.get(
        url,
        headers={"User-Agent": "Aneeta-CTF-Pi/1.0 authorized importer"},
        timeout=TIMEOUT,
        allow_redirects=True,
        stream=True,
    )
    response.raise_for_status()

    content_type = response.headers.get("Content-Type", "")
    if "text/html" not in content_type.lower():
        raise ValueError(
            f"HTML page එකක් නොවේ. Content-Type: {content_type or 'Unknown'}"
        )

    raw = response.raw.read(MAX_PAGE + 1, decode_content=True)
    if len(raw) > MAX_PAGE:
        raise ValueError("Page එක 2 MB limit එකට වඩා විශාලයි.")

    html = raw.decode(response.encoding or "utf-8", errors="replace")
    soup = BeautifulSoup(html, "html.parser")
    title = soup.title.get_text(" ", strip=True) if soup.title else "Untitled"
    visible = clean_text(html)
    comments = [
        str(item).strip()
        for item in soup.find_all(
            string=lambda value: isinstance(value, Comment)
        )
        if str(item).strip()
    ][:200]

    final_host = urlparse(response.url).hostname
    attachments: list[str] = []
    for anchor in soup.find_all("a", href=True):
        absolute = urljoin(response.url, anchor["href"])
        parsed = urlparse(absolute)
        clean_path = parsed.path.lower()
        if (
            parsed.scheme in {"http", "https"}
            and parsed.hostname == final_host
            and clean_path.endswith(ATTACHMENT_EXTENSIONS)
            and absolute not in attachments
        ):
            attachments.append(absolute)

    steps = [
        Step(
            "URL import",
            f"Requested: {url}\nFinal: {response.url}\n"
            f"Status: {response.status_code}\nTitle: {title}\n"
            f"Content-Type: {content_type or 'Unknown'}",
        ).to_dict(),
        Step("Visible page text", visible[:12000] or "No visible text.").to_dict(),
    ]
    if comments:
        steps.append(
            Step("HTML comments", "\n\n".join(comments)[:12000]).to_dict()
        )
    if attachments:
        steps.append(
            Step("Attachment links", "\n".join(attachments[:100])).to_dict()
        )

    decoded_steps, decoded_outputs = analyze_encodings(visible)
    steps.extend(decoded_steps)

    detected = detect_flag_format("\n".join([visible, *comments]))
    searchable = [title, response.url, visible, html, *comments, *attachments]
    searchable.extend(decoded_outputs)

    return {
        "steps": steps,
        "report": Report(
            "url",
            "Challenge URL",
            {
                "title": title,
                "requested_url": url,
                "final_url": response.url,
                "status": response.status_code,
                "content_type": content_type or "Unknown",
                "attachment_links": attachments,
                "detected_flag_format": detected,
            },
        ).to_dict(),
        "searchable_text": searchable,
        "detected_flag_format": detected,
    }
