from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import time
from urllib.parse import urljoin

from playwright.sync_api import (
    Error as PlaywrightError,
    TimeoutError as PlaywrightTimeoutError,
    sync_playwright,
)

from aneeta.autopilot.engine import AutopilotEngine
from aneeta.replay.submission_queue import SubmissionQueue
from aneeta.tournament.candidates import rank_flag_candidates
from aneeta.tournament.config import AdapterConfig
from aneeta.tournament.logging_store import TournamentLog
from aneeta.tournament.scope import ScopeViolation, assert_allowed_url


class TournamentRunnerError(RuntimeError):
    pass


@dataclass
class RunnerPaths:
    base_dir: Path
    stop_file: Path
    log_file: Path
    queue_file: Path

    @classmethod
    def from_base(cls, base_dir: Path, adapter_name: str) -> "RunnerPaths":
        safe_name = "".join(
            char if char.isalnum() or char in "-_" else "_"
            for char in adapter_name.lower()
        ).strip("_") or "adapter"
        return cls(
            base_dir=base_dir,
            stop_file=base_dir / "runtime" / "STOP_AUTOMATION",
            log_file=(
                base_dir
                / "runtime"
                / "tournament_logs"
                / f"{safe_name}.jsonl"
            ),
            queue_file=(
                base_dir
                / "runtime"
                / "submissions"
                / "queue.json"
            ),
        )


class BrowserTournamentRunner:
    def __init__(
        self,
        config: AdapterConfig,
        autopilot: AutopilotEngine,
        paths: RunnerPaths,
    ):
        self.config = config
        self.autopilot = autopilot
        self.paths = paths
        self.log = TournamentLog(paths.log_file)
        self.queue = SubmissionQueue(paths.queue_file)

    def _check_stop(self) -> None:
        if self.paths.stop_file.exists():
            raise TournamentRunnerError(
                f"Emergency stop file detected: {self.paths.stop_file}"
            )

    def _read_text(self, page, selector: str, label: str) -> str:
        locator = page.locator(selector).first
        try:
            value = locator.inner_text(timeout=10000).strip()
        except PlaywrightError as exc:
            raise TournamentRunnerError(
                f"Could not read {label} using selector `{selector}`."
            ) from exc
        if not value:
            raise TournamentRunnerError(f"{label} was empty.")
        return value

    def _marker_visible(self, page, selector: str) -> bool:
        try:
            locator = page.locator(selector).first
            return locator.count() > 0 and locator.is_visible(timeout=1000)
        except PlaywrightError:
            return False

    def _wait_for_result(self, page) -> str:
        correct = self.config.selectors["correct_marker"]
        incorrect = self.config.selectors["incorrect_marker"]
        deadline = time.monotonic() + self.config.response_timeout_ms / 1000

        while time.monotonic() < deadline:
            self._check_stop()
            assert_allowed_url(page.url, self.config.allowed_origins)
            if self._marker_visible(page, correct):
                return "correct"
            if self._marker_visible(page, incorrect):
                return "incorrect"
            page.wait_for_timeout(250)
        return "ambiguous"

    def _queue_candidate(
        self,
        challenge_key: str,
        title: str,
        candidate: dict,
    ) -> None:
        self.queue.add(
            challenge_id=challenge_key,
            challenge_title=title,
            flag=str(candidate["flag"]),
            platform=self.config.name,
        )

    def login_only(self, headless: bool = False) -> None:
        profile_dir = self.paths.base_dir / self.config.profile_dir
        profile_dir.mkdir(parents=True, exist_ok=True)

        with sync_playwright() as playwright:
            context = playwright.chromium.launch_persistent_context(
                user_data_dir=str(profile_dir),
                headless=headless,
                viewport={"width": 1280, "height": 800},
                accept_downloads=False,
            )
            page = context.pages[0] if context.pages else context.new_page()
            target = self.config.manual_login_url or self.config.start_url
            assert_allowed_url(target, self.config.allowed_origins)
            page.goto(target, wait_until="domcontentloaded", timeout=45000)
            print("\nLogin-only mode")
            print("Log in manually and complete CAPTCHA/MFA yourself.")
            print("Do not enter credentials in this terminal.")
            input("Press Enter here after the browser session is ready: ")
            context.close()

    def run(
        self,
        *,
        live: bool,
        confirm_permission: bool,
        headless: bool = False,
    ) -> dict:
        if live:
            if not self.config.automation_permitted:
                raise TournamentRunnerError(
                    "This adapter has automation_permitted=false."
                )
            if not confirm_permission:
                raise TournamentRunnerError(
                    "Live mode requires --confirm-permission."
                )

        self._check_stop()

        profile_dir = self.paths.base_dir / self.config.profile_dir
        profile_dir.mkdir(parents=True, exist_ok=True)

        limits = self.config.limits
        max_challenges = int(limits["max_challenges"])
        max_attempts = int(limits["max_attempts_per_challenge"])
        min_confidence = float(limits["min_confidence"])
        delay_seconds = float(limits["delay_seconds"])
        rejection_limit = int(limits["stop_after_rejections"])

        completed = 0
        total_rejections = 0
        seen: set[str] = set()
        summary = {
            "adapter": self.config.name,
            "mode": "live" if live else "dry-run",
            "completed": 0,
            "rejections": 0,
            "stopped_reason": "",
        }

        with sync_playwright() as playwright:
            context = playwright.chromium.launch_persistent_context(
                user_data_dir=str(profile_dir),
                headless=headless,
                viewport={"width": 1280, "height": 800},
                accept_downloads=False,
            )
            page = context.pages[0] if context.pages else context.new_page()

            assert_allowed_url(
                self.config.start_url,
                self.config.allowed_origins,
            )
            page.goto(
                self.config.start_url,
                wait_until="domcontentloaded",
                timeout=45000,
            )

            try:
                while completed < max_challenges:
                    self._check_stop()
                    assert_allowed_url(page.url, self.config.allowed_origins)

                    title = self._read_text(
                        page,
                        self.config.selectors["challenge_title"],
                        "challenge title",
                    )
                    challenge_text = self._read_text(
                        page,
                        self.config.selectors["challenge_text"],
                        "challenge text",
                    )
                    challenge_key = f"{page.url}|{title}"

                    if challenge_key in seen:
                        summary["stopped_reason"] = "Challenge loop detected."
                        break
                    seen.add(challenge_key)

                    solved = self.autopilot.run(
                        challenge_text=challenge_text,
                        flag_format=self.config.flag_format,
                    )
                    candidates = rank_flag_candidates(
                        challenge_text=challenge_text,
                        findings=solved["findings"],
                        flag_format=self.config.flag_format,
                    )

                    self.log.append("challenge_analyzed", {
                        "url": page.url,
                        "title": title,
                        "plan": solved["plan"],
                        "candidates": candidates,
                    })

                    eligible = [
                        item for item in candidates
                        if float(item["confidence"]) >= min_confidence
                    ][:max_attempts]

                    if not eligible:
                        if candidates:
                            self._queue_candidate(
                                challenge_key,
                                title,
                                candidates[0],
                            )
                        summary["stopped_reason"] = (
                            "No candidate met the confidence threshold."
                        )
                        break

                    if not live:
                        self._queue_candidate(
                            challenge_key,
                            title,
                            eligible[0],
                        )
                        self.log.append("dry_run_candidate", {
                            "title": title,
                            "candidate": eligible[0],
                        })
                        summary["stopped_reason"] = (
                            "Dry-run completed without submitting."
                        )
                        break

                    solved_current = False
                    for attempt_index, candidate in enumerate(eligible, start=1):
                        self._check_stop()
                        assert_allowed_url(
                            page.url,
                            self.config.allowed_origins,
                        )

                        flag = str(candidate["flag"])
                        page.locator(
                            self.config.selectors["flag_input"]
                        ).first.fill(flag)
                        page.locator(
                            self.config.selectors["submit_button"]
                        ).first.click()

                        status = self._wait_for_result(page)
                        self.log.append("submission_result", {
                            "title": title,
                            "flag": flag,
                            "confidence": candidate["confidence"],
                            "attempt": attempt_index,
                            "status": status,
                        })

                        if status == "correct":
                            solved_current = True
                            completed += 1
                            summary["completed"] = completed
                            print(
                                f"[CORRECT] {title}: {flag} "
                                f"({candidate['confidence']:.2f})"
                            )
                            break

                        if status == "incorrect":
                            total_rejections += 1
                            summary["rejections"] = total_rejections
                            print(f"[REJECTED] {title}: {flag}")
                            if total_rejections >= rejection_limit:
                                raise TournamentRunnerError(
                                    "Global rejection limit reached."
                                )
                            time.sleep(delay_seconds)
                            continue

                        self._queue_candidate(
                            challenge_key,
                            title,
                            candidate,
                        )
                        raise TournamentRunnerError(
                            "Platform response was ambiguous; stopped."
                        )

                    if not solved_current:
                        summary["stopped_reason"] = (
                            "No submitted candidate was accepted."
                        )
                        break

                    next_locator = page.locator(
                        self.config.selectors["next_link"]
                    ).first
                    if next_locator.count() == 0:
                        summary["stopped_reason"] = "No next challenge link."
                        break

                    href = next_locator.get_attribute("href")
                    if href:
                        next_url = urljoin(page.url, href)
                        assert_allowed_url(
                            next_url,
                            self.config.allowed_origins,
                        )

                    next_locator.click()
                    try:
                        page.wait_for_load_state(
                            "domcontentloaded",
                            timeout=15000,
                        )
                    except PlaywrightTimeoutError:
                        pass

                    assert_allowed_url(
                        page.url,
                        self.config.allowed_origins,
                    )
                    time.sleep(delay_seconds)

            except (ScopeViolation, TournamentRunnerError) as exc:
                summary["stopped_reason"] = str(exc)
                self.log.append("runner_stopped", summary)
            finally:
                context.close()

        self.log.append("runner_finished", summary)
        return summary
