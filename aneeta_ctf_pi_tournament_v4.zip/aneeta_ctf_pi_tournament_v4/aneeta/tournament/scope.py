from __future__ import annotations

from urllib.parse import urlparse

from aneeta.tournament.config import canonical_origin_from_url


class ScopeViolation(RuntimeError):
    pass


def assert_allowed_url(url: str, allowed_origins: tuple[str, ...]) -> None:
    origin = canonical_origin_from_url(url)
    if origin not in allowed_origins:
        raise ScopeViolation(
            f"Navigation left the exact allowlist: {origin}"
        )

    parsed = urlparse(url)
    if parsed.username or parsed.password:
        raise ScopeViolation("Credentials inside URLs are not permitted.")
