from __future__ import annotations

from collections import defaultdict

from aneeta.solvers.flag_detector import find_flags


def rank_flag_candidates(
    challenge_text: str,
    findings: list[dict],
    flag_format: str,
) -> list[dict]:
    scores: dict[str, float] = {}
    evidence: dict[str, list[str]] = defaultdict(list)
    support: dict[str, set[str]] = defaultdict(set)

    for flag in find_flags(challenge_text, custom_format=flag_format):
        scores[flag] = max(scores.get(flag, 0), 0.99)
        evidence[flag].append("Flag appeared directly in challenge text.")
        support[flag].add("direct")

    for item in findings:
        output = str(item.get("output", ""))
        plugin_id = str(item.get("plugin_id", "unknown"))
        plugin_name = str(item.get("plugin_name", plugin_id))
        confidence = max(
            0.0,
            min(float(item.get("confidence", 0.0)), 1.0),
        )

        for flag in find_flags(output, custom_format=flag_format):
            scores[flag] = max(scores.get(flag, 0), confidence)
            evidence[flag].append(
                f"{plugin_name} produced the candidate at "
                f"confidence {confidence:.2f}."
            )
            support[flag].add(plugin_id)

    ranked = []
    for flag, base_score in scores.items():
        independent_support = len(support[flag])
        bonus = min(max(independent_support - 1, 0) * 0.02, 0.06)
        ranked.append({
            "flag": flag,
            "confidence": min(base_score + bonus, 1.0),
            "support_count": independent_support,
            "evidence": evidence[flag],
        })

    ranked.sort(
        key=lambda item: (
            -float(item["confidence"]),
            -int(item["support_count"]),
            item["flag"],
        )
    )
    return ranked
