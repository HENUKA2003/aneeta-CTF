from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
from typing import Any
from urllib.parse import urlparse


class AdapterConfigError(ValueError):
    pass


@dataclass(frozen=True)
class AdapterConfig:
    name: str
    automation_permitted: bool
    allowed_origins: tuple[str, ...]
    start_url: str
    manual_login_url: str
    profile_dir: str
    flag_format: str
    selectors: dict[str, str]
    limits: dict[str, float | int]
    response_timeout_ms: int

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "automation_permitted": self.automation_permitted,
            "allowed_origins": list(self.allowed_origins),
            "start_url": self.start_url,
            "manual_login_url": self.manual_login_url,
            "profile_dir": self.profile_dir,
            "flag_format": self.flag_format,
            "selectors": dict(self.selectors),
            "limits": dict(self.limits),
            "response_timeout_ms": self.response_timeout_ms,
        }


REQUIRED_SELECTORS = {
    "challenge_title",
    "challenge_text",
    "flag_input",
    "submit_button",
    "correct_marker",
    "incorrect_marker",
    "next_link",
}


def canonical_origin(value: str) -> str:
    parsed = urlparse(value)
    if parsed.scheme not in {"http", "https"}:
        raise AdapterConfigError("Allowed origin must use HTTP or HTTPS.")
    if not parsed.hostname:
        raise AdapterConfigError("Allowed origin has no hostname.")
    if parsed.path not in {"", "/"} or parsed.query or parsed.fragment:
        raise AdapterConfigError(
            "Allowed origin must contain only scheme, host, and optional port."
        )

    port = parsed.port
    default_port = 443 if parsed.scheme == "https" else 80
    netloc = parsed.hostname.lower()
    if port and port != default_port:
        netloc += f":{port}"
    return f"{parsed.scheme}://{netloc}"


def validate_selectors(selectors: Any) -> dict[str, str]:
    if not isinstance(selectors, dict):
        raise AdapterConfigError("selectors must be a JSON object.")

    missing = sorted(REQUIRED_SELECTORS - set(selectors))
    if missing:
        raise AdapterConfigError(
            "Missing selectors: " + ", ".join(missing)
        )

    clean: dict[str, str] = {}
    for name in REQUIRED_SELECTORS:
        value = str(selectors.get(name, "")).strip()
        if not value:
            raise AdapterConfigError(f"Selector `{name}` cannot be empty.")
        if len(value) > 300:
            raise AdapterConfigError(f"Selector `{name}` is too long.")
        clean[name] = value
    return clean


def validate_limits(value: Any) -> dict[str, float | int]:
    raw = value if isinstance(value, dict) else {}

    limits: dict[str, float | int] = {
        "max_challenges": int(raw.get("max_challenges", 20)),
        "max_attempts_per_challenge": int(
            raw.get("max_attempts_per_challenge", 3)
        ),
        "min_confidence": float(raw.get("min_confidence", 0.90)),
        "delay_seconds": float(raw.get("delay_seconds", 5)),
        "stop_after_rejections": int(raw.get("stop_after_rejections", 5)),
    }

    if not 1 <= int(limits["max_challenges"]) <= 100:
        raise AdapterConfigError("max_challenges must be between 1 and 100.")
    if not 1 <= int(limits["max_attempts_per_challenge"]) <= 5:
        raise AdapterConfigError(
            "max_attempts_per_challenge must be between 1 and 5."
        )
    if not 0.5 <= float(limits["min_confidence"]) <= 1.0:
        raise AdapterConfigError("min_confidence must be between 0.5 and 1.0.")
    if not 1 <= float(limits["delay_seconds"]) <= 60:
        raise AdapterConfigError("delay_seconds must be between 1 and 60.")
    if not 1 <= int(limits["stop_after_rejections"]) <= 20:
        raise AdapterConfigError(
            "stop_after_rejections must be between 1 and 20."
        )
    return limits


def load_adapter(path: Path) -> AdapterConfig:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise AdapterConfigError(f"Adapter file not found: {path}") from exc
    except json.JSONDecodeError as exc:
        raise AdapterConfigError(f"Invalid adapter JSON: {exc}") from exc

    if not isinstance(payload, dict):
        raise AdapterConfigError("Adapter JSON must be an object.")

    origins_raw = payload.get("allowed_origins", [])
    if not isinstance(origins_raw, list) or not origins_raw:
        raise AdapterConfigError("allowed_origins must be a non-empty list.")

    origins: list[str] = []
    for item in origins_raw:
        text = str(item).strip()
        if "*" in text:
            raise AdapterConfigError(
                "Wildcards are not allowed in allowed_origins."
            )
        origin = canonical_origin(text)
        if origin not in origins:
            origins.append(origin)

    start_url = str(payload.get("start_url", "")).strip()
    if not start_url:
        raise AdapterConfigError("start_url is required.")

    start_origin = canonical_origin_from_url(start_url)
    if start_origin not in origins:
        raise AdapterConfigError(
            "start_url origin must be listed in allowed_origins."
        )

    manual_login_url = str(payload.get("manual_login_url", "")).strip()
    if manual_login_url:
        login_origin = canonical_origin_from_url(manual_login_url)
        if login_origin not in origins:
            raise AdapterConfigError(
                "manual_login_url origin must be allowed."
            )

    response_timeout_ms = int(payload.get("response_timeout_ms", 12000))
    if not 1000 <= response_timeout_ms <= 60000:
        raise AdapterConfigError(
            "response_timeout_ms must be between 1000 and 60000."
        )

    return AdapterConfig(
        name=str(payload.get("name", path.stem)).strip() or path.stem,
        automation_permitted=bool(payload.get("automation_permitted", False)),
        allowed_origins=tuple(origins),
        start_url=start_url,
        manual_login_url=manual_login_url,
        profile_dir=str(
            payload.get(
                "profile_dir",
                f"runtime/tournament_profiles/{path.stem}",
            )
        ).strip(),
        flag_format=str(payload.get("flag_format", "")).strip(),
        selectors=validate_selectors(payload.get("selectors")),
        limits=validate_limits(payload.get("limits")),
        response_timeout_ms=response_timeout_ms,
    )


def canonical_origin_from_url(value: str) -> str:
    parsed = urlparse(value)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise AdapterConfigError(f"Invalid HTTP/HTTPS URL: {value}")
    port = parsed.port
    default_port = 443 if parsed.scheme == "https" else 80
    netloc = parsed.hostname.lower()
    if port and port != default_port:
        netloc += f":{port}"
    return f"{parsed.scheme}://{netloc}"
