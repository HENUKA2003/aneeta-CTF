from __future__ import annotations

import hashlib
import mimetypes
from pathlib import Path
import re
import subprocess
import zipfile

from PIL import Image

from aneeta.models import Report, Step
from aneeta.solvers.encoding_solver import analyze_encodings

MAX_TEXT = 512 * 1024
MAX_MEMBER = 2 * 1024 * 1024
MAX_STRINGS = 300
MAX_ENTRIES = 250


def file_description(path: Path) -> str:
    try:
        result = subprocess.run(
            ["file", "-b", str(path)],
            capture_output=True,
            text=True,
            timeout=10,
            check=False,
        )
        return result.stdout.strip() or "Unknown"
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return "Unavailable — install `file` package."


def strings(data: bytes, minimum: int = 4) -> list[str]:
    pattern = rb"[\x20-\x7e]{" + str(minimum).encode() + rb",}"
    found: list[str] = []
    for raw in re.findall(pattern, data):
        value = raw.decode("ascii", errors="ignore").strip()
        if value and value not in found:
            found.append(value)
        if len(found) >= MAX_STRINGS:
            break
    return found


def decode_text(data: bytes) -> str:
    for encoding in ("utf-8", "utf-16", "latin-1"):
        try:
            return data.decode(encoding)
        except UnicodeDecodeError:
            continue
    return ""


def image_metadata(path: Path) -> tuple[list[dict], list[str]]:
    steps: list[dict] = []
    searchable: list[str] = []
    try:
        with Image.open(path) as image:
            lines = [
                f"Format: {image.format}",
                f"Size: {image.width} x {image.height}",
                f"Mode: {image.mode}",
            ]
            for key, value in image.info.items():
                safe = str(value)[:2000]
                lines.append(f"{key}: {safe}")
                searchable.append(f"{key}: {safe}")

            exif = image.getexif()
            for key, value in exif.items():
                safe = str(value)[:2000]
                lines.append(f"EXIF {key}: {safe}")
                searchable.append(f"EXIF {key}: {safe}")

            steps.append(Step("Image metadata", "\n".join(lines)).to_dict())
    except Exception:
        pass
    return steps, searchable


def archive_analysis(path: Path) -> tuple[list[dict], list[str]]:
    steps: list[dict] = []
    searchable: list[str] = []

    if not zipfile.is_zipfile(path):
        return steps, searchable

    with zipfile.ZipFile(path) as archive:
        members = archive.infolist()[:MAX_ENTRIES]
        listing = [f"ZIP entries: {len(archive.infolist())}"]
        for member in members:
            listing.append(f"- {member.filename} ({member.file_size} bytes)")
            searchable.append(member.filename)

            if member.is_dir() or member.file_size > MAX_MEMBER:
                continue

            lower = member.filename.lower()
            if not lower.endswith((
                ".txt", ".md", ".csv", ".json", ".xml", ".html",
                ".js", ".py", ".sh", ".conf", ".ini", ".log"
            )):
                continue

            try:
                data = archive.read(member)
            except RuntimeError:
                steps.append(
                    Step(
                        f"ZIP entry: {member.filename}",
                        "Password-protected or unreadable.",
                        "warning",
                    ).to_dict()
                )
                continue

            decoded = decode_text(data)
            if not decoded:
                continue

            searchable.append(decoded[:MAX_TEXT])
            steps.append(
                Step(
                    f"ZIP text: {member.filename}",
                    decoded[:12000],
                ).to_dict()
            )
            decoded_steps, decoded_outputs = analyze_encodings(decoded[:MAX_TEXT])
            for item in decoded_steps:
                item["title"] = f"{member.filename} → {item['title']}"
            steps.extend(decoded_steps)
            searchable.extend(decoded_outputs)

        steps.insert(0, Step("ZIP analysis", "\n".join(listing)).to_dict())

    return steps, searchable


def analyze_uploaded_file(path: Path, original_name: str) -> dict:
    data = path.read_bytes()
    description = file_description(path)
    mime, _ = mimetypes.guess_type(original_name)
    sha256 = hashlib.sha256(data).hexdigest()
    sha1 = hashlib.sha1(data).hexdigest()
    md5 = hashlib.md5(data).hexdigest()

    report = Report(
        "file",
        "Attachment",
        {
            "name": original_name,
            "size_bytes": len(data),
            "mime": mime or "Unknown",
            "description": description,
            "sha256": sha256,
            "sha1": sha1,
            "md5": md5,
        },
    ).to_dict()

    steps = [
        Step(
            "File information",
            f"Name: {original_name}\nSize: {len(data)} bytes\n"
            f"MIME: {mime or 'Unknown'}\nDetected: {description}\n"
            f"SHA-256: {sha256}\nSHA-1: {sha1}\nMD5: {md5}",
        ).to_dict()
    ]
    searchable = [original_name, description, sha256, sha1, md5]

    extracted = strings(data)
    if extracted:
        joined = "\n".join(extracted)
        steps.append(Step("Printable strings", joined[:12000]).to_dict())
        searchable.append(joined)

    decoded = decode_text(data[:MAX_TEXT])
    if decoded:
        ratio = sum(ch.isprintable() for ch in decoded) / max(len(decoded), 1)
        if ratio > 0.75:
            steps.append(Step("Text preview", decoded[:12000]).to_dict())
            searchable.append(decoded)
            decoded_steps, decoded_outputs = analyze_encodings(decoded)
            steps.extend(decoded_steps)
            searchable.extend(decoded_outputs)

    zip_steps, zip_searchable = archive_analysis(path)
    steps.extend(zip_steps)
    searchable.extend(zip_searchable)

    image_steps, image_searchable = image_metadata(path)
    steps.extend(image_steps)
    searchable.extend(image_searchable)

    return {
        "steps": steps,
        "report": report,
        "searchable_text": searchable,
    }
