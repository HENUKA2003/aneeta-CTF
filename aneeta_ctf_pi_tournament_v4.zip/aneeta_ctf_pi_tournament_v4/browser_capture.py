from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path

from bs4 import BeautifulSoup, Comment
from playwright.sync_api import Error as PlaywrightError
from playwright.sync_api import sync_playwright

BASE_DIR = Path(__file__).resolve().parent
PROFILE_DIR = BASE_DIR / "runtime" / "browser_profile"
CAPTURE_DIR = BASE_DIR / "runtime" / "captures"
LATEST = CAPTURE_DIR / "latest.json"

MAX_HTML = 2_000_000
MAX_TEXT = 1_000_000
ATTACHMENT_EXTENSIONS = (
    ".zip", ".7z", ".rar", ".tar", ".gz", ".tgz",
    ".txt", ".log", ".csv", ".json", ".xml",
    ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp",
    ".pdf", ".pcap", ".pcapng", ".bin", ".elf",
    ".py", ".js", ".sh", ".c", ".cpp", ".java",
)


def ensure_dirs() -> None:
    PROFILE_DIR.mkdir(parents=True, exist_ok=True)
    CAPTURE_DIR.mkdir(parents=True, exist_ok=True)
    for directory in (PROFILE_DIR, CAPTURE_DIR):
        try:
            directory.chmod(0o700)
        except OSError:
            pass


def extract_comments(html: str) -> list[str]:
    soup = BeautifulSoup(html, "html.parser")
    return [
        str(item).strip()
        for item in soup.find_all(
            string=lambda value: isinstance(value, Comment)
        )
        if str(item).strip()
    ][:200]


def capture_page(page) -> Path:
    title = page.title()
    url = page.url

    try:
        visible_text = page.locator("body").inner_text(timeout=10_000)
    except PlaywrightError:
        visible_text = ""

    html = page.content()
    links_raw = page.locator("a[href]").evaluate_all(
        """
        elements => elements.map(element => ({
            href: element.href,
            text: (element.innerText || element.textContent || "").trim()
        }))
        """
    )

    links: list[str] = []
    attachments: list[str] = []
    for item in links_raw[:1000]:
        href = str(item.get("href", "")).strip()
        if not href.startswith(("http://", "https://")):
            continue
        if href not in links:
            links.append(href)
        if href.lower().split("?", 1)[0].endswith(ATTACHMENT_EXTENSIONS):
            if href not in attachments:
                attachments.append(href)

    payload = {
        "captured_at": datetime.now(timezone.utc).isoformat(),
        "title": title,
        "url": url,
        "visible_text": visible_text[:MAX_TEXT],
        "html": html[:MAX_HTML],
        "comments": extract_comments(html),
        "links": links[:500],
        "attachment_links": attachments[:100],
    }

    temp = LATEST.with_suffix(".tmp")
    temp.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    temp.replace(LATEST)

    try:
        LATEST.chmod(0o600)
    except OSError:
        pass

    return LATEST


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Manually log in and capture the current authorized CTF page."
    )
    parser.add_argument(
        "--url",
        default="https://tryhackme.com/",
        help="Starting URL",
    )
    args = parser.parse_args()

    ensure_dirs()
    print("\nAneeta CTF Browser Capture")
    print("1. Chromium opens with a dedicated local profile.")
    print("2. Log in manually and complete CAPTCHA/MFA yourself.")
    print("3. Navigate to the authorized challenge page.")
    print("4. Return here and press Enter to capture.")
    print("5. Type q and press Enter to close.\n")

    with sync_playwright() as playwright:
        context = playwright.chromium.launch_persistent_context(
            user_data_dir=str(PROFILE_DIR),
            headless=False,
            viewport={"width": 1280, "height": 800},
            accept_downloads=False,
        )

        page = context.pages[0] if context.pages else context.new_page()
        try:
            page.goto(args.url, wait_until="domcontentloaded", timeout=45_000)
        except PlaywrightError as exc:
            print(f"Start-page warning: {exc}")

        while True:
            command = input(
                "Enter = capture active page | q = quit: "
            ).strip().lower()
            if command == "q":
                break

            active = [item for item in context.pages if not item.is_closed()]
            if not active:
                print("No open browser page.")
                continue

            try:
                captured = capture_page(active[-1])
                print(f"Captured: {active[-1].title()}")
                print(f"URL: {active[-1].url}")
                print(f"Saved: {captured}\n")
            except Exception as exc:
                print(f"Capture failed: {exc}\n")

        context.close()

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
