# Aneeta CTF Pi Tournament V4 - Setup Guide

## 1. Hardware

Recommended:

- Raspberry Pi 4 with 4 GB or 8 GB RAM
- Raspberry Pi OS 64-bit with Desktop
- 64 GB storage or USB SSD
- Cooling fan/heatsink
- Stable network connection

The Desktop edition is needed when a platform requires manual login in a visible
Chromium window.

## 2. Extract the project

```bash
unzip aneeta_ctf_pi_tournament_v4.zip
cd aneeta_ctf_pi_tournament_v4
chmod +x *.sh
```

## 3. Install the Aneeta application

```bash
./setup_pi.sh
```

This creates `.venv`, installs Python packages, Playwright Chromium, Nmap and the
core dependencies.

## 4. Install optional CTF tools

```bash
./install_ctf_tools.sh
```

The script attempts to install Tshark, ExifTool, Binwalk, Steghide, ZBar,
Poppler, 7-Zip and Radare2. A missing optional package does not stop the full
setup.

## 5. Install Ollama

```bash
./install_ollama_arm64.sh
./pull_ollama_model.sh
```

Check it:

```bash
source .venv/bin/activate
python check_ollama.py
```

The result should show `online: True` and `model_available: True`.

## 6. Start the dashboard

```bash
./run_dashboard.sh
```

Find the Pi IP:

```bash
hostname -I
```

Open this from a laptop or phone on the same network:

```text
http://PI-IP:5000
```

## 7. Test auto-submit safely with the local demo

Open Terminal 1:

```bash
cd aneeta_ctf_pi_tournament_v4
./start_demo.sh
```

The local practice platform runs at:

```text
http://127.0.0.1:8088
```

Open Terminal 2 and test dry-run:

```bash
cd aneeta_ctf_pi_tournament_v4
./run_demo_dry.sh
```

Dry-run solves the first challenge and puts the flag in the manual queue without
submitting it.

Clear an old emergency stop before live testing:

```bash
./clear_emergency_stop.sh
```

Run the complete local live test:

```bash
./run_demo_live.sh
```

Expected behavior:

1. Challenge text is read.
2. Ollama/deterministic plugins solve it.
3. A candidate above 0.90 confidence is submitted.
4. The page confirms correct or incorrect.
5. Correct moves to the next challenge.
6. The runner stops after the final challenge.

## 8. Create a real platform adapter

Copy the template:

```bash
cp adapters/template_platform.json adapters/my_platform.json
nano adapters/my_platform.json
```

Set:

- `name`
- exact `allowed_origins`
- `start_url`
- optional `manual_login_url`
- platform flag format
- seven CSS selectors

Do not use wildcard domains.

Keep this while testing:

```json
"automation_permitted": false
```

## 9. Save a manual login session

```bash
source .venv/bin/activate
python tournament_runner.py \
  --config adapters/my_platform.json \
  --login-only
```

Log in manually in Chromium. Complete CAPTCHA/MFA yourself. Return to the
terminal and press Enter. Credentials are not stored in the project code; the
browser profile stores the session cookies locally.

## 10. Test the real adapter in dry-run

```bash
python tournament_runner.py \
  --config adapters/my_platform.json \
  --dry-run
```

Check:

- Correct challenge title was read.
- Correct challenge text was read.
- The right flag format was detected.
- No button was clicked.
- The candidate was added to the manual queue.
- The browser stayed inside the exact allowed origin.

## 11. Enable live mode

Only after confirming the competition/platform permits automation, edit:

```json
"automation_permitted": true
```

Then run:

```bash
python tournament_runner.py \
  --config adapters/my_platform.json \
  --live \
  --confirm-permission
```

Both the JSON setting and CLI confirmation are required.

## 12. Emergency stop

From another terminal:

```bash
./emergency_stop.sh
```

The runner checks `runtime/STOP_AUTOMATION` before challenges and submissions.

Clear it:

```bash
./clear_emergency_stop.sh
```

The dashboard also has Emergency Stop and Clear Stop buttons.

## 13. Logs

Tournament events:

```text
runtime/tournament_logs/
```

Manual flag queue:

```text
runtime/submissions/queue.json
```

Browser profiles:

```text
runtime/tournament_profiles/
```

Do not share browser profile folders because they contain login sessions.

## 14. Run tests

```bash
source .venv/bin/activate
python -m unittest discover -s tests -v
```
