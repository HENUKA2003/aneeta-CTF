#!/usr/bin/env bash
set -euo pipefail

MODEL="${OLLAMA_MODEL:-llama3.2:1b}"
echo "Pulling ${MODEL}..."
ollama pull "${MODEL}"
echo "Ready: ${MODEL}"
