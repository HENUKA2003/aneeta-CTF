#!/usr/bin/env bash
set -euo pipefail

ARCH="$(uname -m)"
if [[ "${ARCH}" != "aarch64" && "${ARCH}" != "arm64" ]]; then
  echo "This helper is intended for 64-bit ARM Linux."
  echo "Detected: ${ARCH}"
  exit 1
fi

curl -fsSL https://ollama.com/download/ollama-linux-arm64.tar.zst \
  | sudo tar x -C /usr

if ! id ollama >/dev/null 2>&1; then
  sudo useradd -r -s /bin/false -U -m -d /usr/share/ollama ollama
fi

sudo tee /etc/systemd/system/ollama.service >/dev/null <<'EOF'
[Unit]
Description=Ollama Service
After=network-online.target
Wants=network-online.target

[Service]
ExecStart=/usr/bin/ollama serve
User=ollama
Group=ollama
Restart=always
RestartSec=3
Environment="PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable --now ollama

echo "Ollama installed and started."
echo "Next: ./pull_ollama_model.sh"
