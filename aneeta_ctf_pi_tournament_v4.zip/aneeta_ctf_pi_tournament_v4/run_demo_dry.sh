#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
source .venv/bin/activate
exec python tournament_runner.py \
  --config adapters/demo_local.json \
  --dry-run
