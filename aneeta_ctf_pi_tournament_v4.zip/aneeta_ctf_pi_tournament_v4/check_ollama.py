from __future__ import annotations

import os

from aneeta.ollama.client import OllamaClient


client = OllamaClient(
    base_url=os.getenv("OLLAMA_URL", "http://127.0.0.1:11434"),
    model=os.getenv("OLLAMA_MODEL", "llama3.2:1b"),
)
print(client.status())
