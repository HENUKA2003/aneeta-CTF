# Aneeta CTF Pi Tournament V4 - User Guide

## Main modes

### Category Labs

Use the dashboard for:

- Crypto text
- Web challenge URLs
- Forensics attachments
- Misc clues
- Logged-in page captures
- Exact authorized IP recon

### Replay Mode

Solves local old challenges, verifies known answers and awards local points.

### Tournament Runner

Reads the current challenge page, solves visible challenge text, optionally
submits a high-confidence flag, checks the result and moves to the next page.

## Tournament Runner command modes

### Login only

```bash
python tournament_runner.py \
  --config adapters/my_platform.json \
  --login-only
```

Use this to log in manually and save the browser session.

### Dry-run

```bash
python tournament_runner.py \
  --config adapters/my_platform.json \
  --dry-run
```

Dry-run:

- Reads one challenge
- Runs Ollama and allowlisted solvers
- Ranks flag candidates
- Adds the best candidate to the manual queue
- Does not submit

Always use dry-run before live mode.

### Live

```bash
python tournament_runner.py \
  --config adapters/my_platform.json \
  --live \
  --confirm-permission
```

Live mode:

1. Reads challenge title and text.
2. Runs the solver pipeline.
3. Keeps candidates above the confidence threshold.
4. Submits up to the configured attempt limit.
5. Detects correct/incorrect markers.
6. Moves to the configured next link only after a correct result.
7. Stops if the response is ambiguous, the rejection limit is reached, the
   domain changes or the emergency stop file appears.

## Adapter fields

### `automation_permitted`

```json
"automation_permitted": false
```

Keep false until the platform rules explicitly permit automation.

### `allowed_origins`

```json
"allowed_origins": [
  "https://ctf.example.com"
]
```

Only exact origins are accepted. Wildcards are rejected.

### Page selectors

```json
"selectors": {
  "challenge_title": "#challenge-title",
  "challenge_text": "#challenge-text",
  "flag_input": "input[name=flag]",
  "submit_button": "button[type=submit]",
  "correct_marker": ".result.correct",
  "incorrect_marker": ".result.incorrect",
  "next_link": "a.next"
}
```

Use the browser developer tools to inspect the page and copy stable CSS
selectors. Avoid random/generated class names where possible.

### Limits

```json
"limits": {
  "max_challenges": 20,
  "max_attempts_per_challenge": 3,
  "min_confidence": 0.90,
  "delay_seconds": 5,
  "stop_after_rejections": 5
}
```

- `max_challenges`: maximum pages in one run
- `max_attempts_per_challenge`: maximum candidate flags
- `min_confidence`: candidates below this are not submitted
- `delay_seconds`: delay between actions
- `stop_after_rejections`: global rejection safety stop

## Confidence ranking

Typical values:

- `0.99`: flag directly present in collected challenge text
- `0.90-0.98`: deterministic decode produced the flag
- Extra small bonus: independent plugins support the same candidate
- Below threshold: placed in manual review, not submitted

Ollama-only guesses without deterministic evidence should not be trusted as
high-confidence answers.

## Emergency stop

Terminal:

```bash
./emergency_stop.sh
```

Dashboard:

- Press **Emergency Stop**
- The status changes to ACTIVE

Clear:

```bash
./clear_emergency_stop.sh
```

## Common problems

### `Adapter has automation_permitted=false`

The adapter is still protected. Keep it false for dry-run. Change it only when
the rules allow live automation.

### `Live mode requires --confirm-permission`

Add:

```text
--confirm-permission
```

This is a second deliberate confirmation.

### `Navigation left the exact allowlist`

The page redirected to another origin. Add an origin only when it is genuinely
part of the authorized platform and the rules permit it. Never use a wildcard.

### `No candidate met the confidence threshold`

The solver did not have enough deterministic evidence. Check the manual
dashboard, add another safe solver plugin or lower the threshold only for a
controlled test.

### `Platform response was ambiguous`

The configured correct/incorrect selectors were not visible. Fix those selectors
and retest in dry-run before live mode.

### Browser opens but is logged out

Run login-only mode again. Do not delete the adapter's profile folder.

### Ollama offline

```bash
sudo systemctl restart ollama
source .venv/bin/activate
python check_ollama.py
```

## What the runner does not do

- CAPTCHA or MFA bypass
- Password attacks
- Account creation
- Exploit target machines
- Change passwords
- Add persistence
- Run unrestricted shell commands
- Submit to domains outside the adapter allowlist
- Continue after ambiguous platform responses

## Recommended competition workflow

1. Confirm rules.
2. Prepare and dry-run adapters before the competition.
3. Use auto-submit for common high-confidence text challenges only.
4. Use the manual queue for uncertain answers.
5. Keep a teammate watching the log and emergency stop.
6. Let human teammates handle custom web exploitation, advanced reversing and
   pwn challenges.
